-- =============================================
-- Volleyball League Database - Encryption Script (CORRECTED)
-- Contains: Column-Level Encryption for Sensitive Data
-- =============================================

USE VolleyballLeague;
GO

PRINT '========================================';
PRINT 'Implementing Column-Level Encryption';
PRINT '========================================';
PRINT '';

-- =============================================
-- STEP 1: Create Database Master Key
-- =============================================
PRINT 'Step 1: Creating Database Master Key...';

-- Check if master key exists
IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
BEGIN
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'VolleyballLeague2025!StrongPassword#';
    PRINT 'Database Master Key created successfully.';
END
ELSE
BEGIN
    PRINT 'Database Master Key already exists.';
END
PRINT '';
GO

-- =============================================
-- STEP 2: Create Certificate
-- =============================================
PRINT 'Step 2: Creating Certificate for Encryption...';

-- Drop certificate if exists
IF EXISTS (SELECT * FROM sys.certificates WHERE name = 'VolleyballLeagueCert')
BEGIN
    DROP CERTIFICATE VolleyballLeagueCert;
    PRINT 'Existing certificate dropped.';
END

CREATE CERTIFICATE VolleyballLeagueCert
WITH SUBJECT = 'Certificate for Volleyball League Sensitive Data',
     EXPIRY_DATE = '2030-12-31';
     
PRINT 'Certificate created successfully.';
PRINT 'Certificate Name: VolleyballLeagueCert';
PRINT 'Expiry Date: 2030-12-31';
PRINT '';
GO

-- =============================================
-- STEP 3: Create Symmetric Key
-- =============================================
PRINT 'Step 3: Creating Symmetric Key for Encryption...';

-- Drop symmetric key if exists
IF EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = 'VolleyballLeagueSymKey')
BEGIN
    DROP SYMMETRIC KEY VolleyballLeagueSymKey;
    PRINT 'Existing symmetric key dropped.';
END

CREATE SYMMETRIC KEY VolleyballLeagueSymKey
WITH ALGORITHM = AES_256
ENCRYPTION BY CERTIFICATE VolleyballLeagueCert;

PRINT 'Symmetric Key created successfully.';
PRINT 'Algorithm: AES_256';
PRINT '';
GO

-- =============================================
-- STEP 4: Add Encrypted Columns to Customer Table
-- =============================================
PRINT 'Step 4: Adding Encrypted Columns to Customer Table...';

-- Add encrypted email column
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Customer') AND name = 'Email_Encrypted')
BEGIN
    ALTER TABLE Customer
    ADD Email_Encrypted VARBINARY(256) NULL;
    PRINT 'Email_Encrypted column added.';
END

-- Add encrypted phone column
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Customer') AND name = 'Phone_Encrypted')
BEGIN
    ALTER TABLE Customer
    ADD Phone_Encrypted VARBINARY(128) NULL;
    PRINT 'Phone_Encrypted column added.';
END

-- Add encrypted street address column
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Customer') AND name = 'Street_Encrypted')
BEGIN
    ALTER TABLE Customer
    ADD Street_Encrypted VARBINARY(256) NULL;
    PRINT 'Street_Encrypted column added.';
END

PRINT 'Encrypted columns added to Customer table successfully.';
PRINT '';
GO

-- =============================================
-- STEP 5: Add Encrypted Columns to Coach Table
-- =============================================
PRINT 'Step 5: Adding Encrypted Columns to Coach Table...';

-- Add encrypted email column
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Coach') AND name = 'Email_Encrypted')
BEGIN
    ALTER TABLE Coach
    ADD Email_Encrypted VARBINARY(256) NULL;
    PRINT 'Email_Encrypted column added to Coach table.';
END

PRINT 'Encrypted columns added to Coach table successfully.';
PRINT '';
GO

-- =============================================
-- STEP 6: Add Encrypted Columns to Payment Table
-- =============================================
PRINT 'Step 6: Adding Encrypted Columns to Payment Table...';

-- Add encrypted payment method column (for credit card info)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Payment') AND name = 'PaymentDetails_Encrypted')
BEGIN
    ALTER TABLE Payment
    ADD PaymentDetails_Encrypted VARBINARY(512) NULL;
    PRINT 'PaymentDetails_Encrypted column added to Payment table.';
END

PRINT 'Encrypted columns added to Payment table successfully.';
PRINT '';
GO

-- =============================================
-- STEP 7: Encrypt Existing Data
-- =============================================
PRINT 'Step 7: Encrypting Existing Data...';

-- Open the symmetric key
OPEN SYMMETRIC KEY VolleyballLeagueSymKey
DECRYPTION BY CERTIFICATE VolleyballLeagueCert;

-- Encrypt Customer Email
UPDATE Customer
SET Email_Encrypted = EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), Email)
WHERE Email_Encrypted IS NULL;
PRINT 'Customer emails encrypted: ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' rows';

-- Encrypt Customer Phone
UPDATE Customer
SET Phone_Encrypted = EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), Phone)
WHERE Phone IS NOT NULL AND Phone_Encrypted IS NULL;
PRINT 'Customer phones encrypted: ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' rows';

-- Encrypt Customer Street Address
UPDATE Customer
SET Street_Encrypted = EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), Street)
WHERE Street IS NOT NULL AND Street_Encrypted IS NULL;
PRINT 'Customer street addresses encrypted: ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' rows';

-- Encrypt Coach Email
UPDATE Coach
SET Email_Encrypted = EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), Email)
WHERE Email_Encrypted IS NULL;
PRINT 'Coach emails encrypted: ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' rows';

-- Encrypt Payment Details (storing method as encrypted for demonstration)
UPDATE Payment
SET PaymentDetails_Encrypted = EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), 
    Method + '|' + CAST(PaymentID AS VARCHAR(10)))
WHERE PaymentDetails_Encrypted IS NULL;
PRINT 'Payment details encrypted: ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' rows';

-- Close the symmetric key
CLOSE SYMMETRIC KEY VolleyballLeagueSymKey;

PRINT 'All existing data encrypted successfully.';
PRINT '';
GO

-- =============================================
-- STEP 8: Create Views for Encrypted Data Access
-- =============================================
PRINT 'Step 8: Creating Views for Encrypted Data Access...';

-- View for Customer Secure Data
IF OBJECT_ID('vw_CustomerSecureData', 'V') IS NOT NULL
    DROP VIEW vw_CustomerSecureData;
GO

CREATE VIEW vw_CustomerSecureData
AS
SELECT 
    CustomerID,
    FirstName,
    LastName,
    CONVERT(VARCHAR(255), DecryptByKey(Email_Encrypted)) AS Email_Decrypted,
    Email,
    CONVERT(VARCHAR(15), DecryptByKey(Phone_Encrypted)) AS Phone_Decrypted,
    Phone,
    CONVERT(VARCHAR(200), DecryptByKey(Street_Encrypted)) AS Street_Decrypted,
    Street,
    City,
    StateProvince,
    Country,
    ZipCode
FROM Customer;
GO

PRINT 'View created: vw_CustomerSecureData';
GO

-- View for Coach Secure Data
IF OBJECT_ID('vw_CoachSecureData', 'V') IS NOT NULL
    DROP VIEW vw_CoachSecureData;
GO

CREATE VIEW vw_CoachSecureData
AS
SELECT 
    CoachID,
    FirstName,
    LastName,
    YearsOfExperience,
    CONVERT(VARCHAR(255), DecryptByKey(Email_Encrypted)) AS Email_Decrypted,
    Email
FROM Coach;
GO

PRINT 'View created: vw_CoachSecureData';
GO

-- View for Payment Secure Data
IF OBJECT_ID('vw_PaymentSecureData', 'V') IS NOT NULL
    DROP VIEW vw_PaymentSecureData;
GO

CREATE VIEW vw_PaymentSecureData
AS
SELECT 
    PaymentID,
    OrderID,
    Method,
    Amount,
    PaidAt,
    Status,
    CONVERT(VARCHAR(512), DecryptByKey(PaymentDetails_Encrypted)) AS PaymentDetails_Decrypted
FROM Payment;
GO

PRINT 'View created: vw_PaymentSecureData';
PRINT '';
GO

-- =============================================
-- STEP 9: Create Stored Procedures for Secure Operations
-- =============================================
PRINT 'Step 9: Creating Stored Procedures for Secure Data Operations...';
GO

-- Procedure to insert customer with encrypted data
IF OBJECT_ID('usp_InsertCustomerSecure', 'P') IS NOT NULL
    DROP PROCEDURE usp_InsertCustomerSecure;
GO

CREATE PROCEDURE usp_InsertCustomerSecure
    @FirstName VARCHAR(25),
    @LastName VARCHAR(25),
    @Email VARCHAR(255),
    @Phone VARCHAR(15) = NULL,
    @Street VARCHAR(200) = NULL,
    @City VARCHAR(200) = NULL,
    @StateProvince VARCHAR(100) = NULL,
    @Country VARCHAR(100) = NULL,
    @ZipCode CHAR(9) = NULL,
    @NewCustomerID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Open symmetric key
        OPEN SYMMETRIC KEY VolleyballLeagueSymKey
        DECRYPTION BY CERTIFICATE VolleyballLeagueCert;
        
        -- Insert customer with encrypted sensitive data
        INSERT INTO Customer (
            FirstName, LastName, Email, Phone, Street,
            City, StateProvince, Country, ZipCode,
            Email_Encrypted, Phone_Encrypted, Street_Encrypted
        )
        VALUES (
            @FirstName, @LastName, @Email, @Phone, @Street,
            @City, @StateProvince, @Country, @ZipCode,
            EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), @Email),
            EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), @Phone),
            EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), @Street)
        );
        
        SET @NewCustomerID = SCOPE_IDENTITY();
        
        -- Close symmetric key
        CLOSE SYMMETRIC KEY VolleyballLeagueSymKey;
        
        COMMIT TRANSACTION;
        
        PRINT 'Customer inserted securely with ID: ' + CAST(@NewCustomerID AS VARCHAR(10));
        RETURN 0;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
            
        -- Close key if open
        IF EXISTS (SELECT * FROM sys.openkeys WHERE key_name = 'VolleyballLeagueSymKey')
            CLOSE SYMMETRIC KEY VolleyballLeagueSymKey;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN -1;
    END CATCH
END;
GO

PRINT 'Procedure created: usp_InsertCustomerSecure';
GO

-- Procedure to update customer email securely
IF OBJECT_ID('usp_UpdateCustomerEmailSecure', 'P') IS NOT NULL
    DROP PROCEDURE usp_UpdateCustomerEmailSecure;
GO

CREATE PROCEDURE usp_UpdateCustomerEmailSecure
    @CustomerID INT,
    @NewEmail VARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Validate customer exists
        IF NOT EXISTS (SELECT 1 FROM Customer WHERE CustomerID = @CustomerID)
        BEGIN
            RAISERROR('Customer ID %d does not exist', 16, 1, @CustomerID);
        END
        
        -- Open symmetric key
        OPEN SYMMETRIC KEY VolleyballLeagueSymKey
        DECRYPTION BY CERTIFICATE VolleyballLeagueCert;
        
        -- Update email with encryption
        UPDATE Customer
        SET Email = @NewEmail,
            Email_Encrypted = EncryptByKey(Key_GUID('VolleyballLeagueSymKey'), @NewEmail)
        WHERE CustomerID = @CustomerID;
        
        -- Close symmetric key
        CLOSE SYMMETRIC KEY VolleyballLeagueSymKey;
        
        COMMIT TRANSACTION;
        
        PRINT 'Customer email updated securely for CustomerID: ' + CAST(@CustomerID AS VARCHAR(10));
        RETURN 0;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
            
        -- Close key if open
        IF EXISTS (SELECT * FROM sys.openkeys WHERE key_name = 'VolleyballLeagueSymKey')
            CLOSE SYMMETRIC KEY VolleyballLeagueSymKey;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN -1;
    END CATCH
END;
GO

PRINT 'Procedure created: usp_UpdateCustomerEmailSecure';
PRINT '';
GO

-- =============================================
-- STEP 10: Create Function for Safe Decryption
-- =============================================
PRINT 'Step 10: Creating Function for Safe Decryption...';
GO

IF OBJECT_ID('fn_DecryptSafely', 'FN') IS NOT NULL
    DROP FUNCTION fn_DecryptSafely;
GO

CREATE FUNCTION fn_DecryptSafely
(
    @EncryptedData VARBINARY(MAX),
    @MaxLength INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
    DECLARE @DecryptedData VARCHAR(MAX);
    
    -- Attempt to decrypt
    SET @DecryptedData = CONVERT(VARCHAR(MAX), DecryptByKey(@EncryptedData));
    
    -- If decryption fails or data is null, return masked value
    IF @DecryptedData IS NULL
        SET @DecryptedData = '***ENCRYPTED***';
    ELSE IF @MaxLength > 0
        SET @DecryptedData = LEFT(@DecryptedData, @MaxLength);
    
    RETURN @DecryptedData;
END;
GO

PRINT 'Function created: fn_DecryptSafely';
PRINT '';
GO

-- =============================================
-- STEP 11: Testing and Verification
-- =============================================
PRINT '========================================';
PRINT 'Testing Encryption Implementation';
PRINT '========================================';
PRINT '';

-- Test 1: Insert new customer with encryption
PRINT 'Test 1: Inserting new customer with encrypted data...';

IF NOT EXISTS (SELECT 1 FROM Customer WHERE Email = 'jane.encrypt@secure.com')
BEGIN
    DECLARE @NewCustID INT;
    EXEC usp_InsertCustomerSecure
        @FirstName = 'Jane',
        @LastName = 'Encryption',
        @Email = 'jane.encrypt@secure.com',
        @Phone = '555-8888',
        @Street = '123 Secure Lane',
        @City = 'Boston',
        @StateProvince = 'MA',
        @Country = 'USA',
        @ZipCode = '021011111',
        @NewCustomerID = @NewCustID OUTPUT;
END
ELSE
BEGIN
    PRINT 'Test customer already exists. Skipping insert.';
    SELECT @NewCustID = CustomerID FROM Customer WHERE Email = 'jane.encrypt@secure.com';
    PRINT 'Existing Customer ID: ' + CAST(@NewCustID AS VARCHAR(10));
END
PRINT '';
GO

-- Test 2: View encrypted data (raw)
PRINT 'Test 2: Viewing raw encrypted data...';
SELECT TOP 3
    CustomerID,
    FirstName,
    LastName,
    Email_Encrypted,
    Phone_Encrypted,
    Street_Encrypted
FROM Customer
WHERE Email_Encrypted IS NOT NULL
ORDER BY CustomerID DESC;
PRINT '';
GO

-- Test 3: View decrypted data through view
PRINT 'Test 3: Viewing decrypted data through secure view...';

OPEN SYMMETRIC KEY VolleyballLeagueSymKey
DECRYPTION BY CERTIFICATE VolleyballLeagueCert;

SELECT TOP 3
    CustomerID,
    FirstName,
    LastName,
    Email_Decrypted,
    Phone_Decrypted,
    Street_Decrypted
FROM vw_CustomerSecureData
WHERE Email_Decrypted IS NOT NULL
ORDER BY CustomerID DESC;

CLOSE SYMMETRIC KEY VolleyballLeagueSymKey;
PRINT '';
GO

-- Test 4: Update customer email
PRINT 'Test 4: Updating customer email securely...';

DECLARE @TestCustomerID INT;
SELECT TOP 1 @TestCustomerID = CustomerID 
FROM Customer 
WHERE Email_Encrypted IS NOT NULL
ORDER BY CustomerID;

IF @TestCustomerID IS NOT NULL
BEGIN
    EXEC usp_UpdateCustomerEmailSecure
        @CustomerID = @TestCustomerID,
        @NewEmail = 'updated.email.test@secure.com';
END
ELSE
BEGIN
    PRINT 'No encrypted customers found to test update.';
END
PRINT '';
GO

-- Test 5: Verify coach encryption
PRINT 'Test 5: Verifying coach email encryption...';

OPEN SYMMETRIC KEY VolleyballLeagueSymKey
DECRYPTION BY CERTIFICATE VolleyballLeagueCert;

SELECT TOP 3
    CoachID,
    FirstName,
    LastName,
    Email_Decrypted
FROM vw_CoachSecureData
WHERE Email_Decrypted IS NOT NULL
ORDER BY CoachID;

CLOSE SYMMETRIC KEY VolleyballLeagueSymKey;
PRINT '';
GO

-- Test 6: Verify encryption/decryption cycle
PRINT 'Test 6: Verifying encryption/decryption cycle...';

OPEN SYMMETRIC KEY VolleyballLeagueSymKey
DECRYPTION BY CERTIFICATE VolleyballLeagueCert;

SELECT TOP 1
    CustomerID,
    FirstName,
    LastName,
    'Original Email' = Email,
    'Encrypted (Binary)' = Email_Encrypted,
    'Decrypted Email' = CONVERT(VARCHAR(255), DecryptByKey(Email_Encrypted)),
    'Match?' = CASE 
        WHEN Email = CONVERT(VARCHAR(255), DecryptByKey(Email_Encrypted)) 
        THEN 'YES ?' 
        ELSE 'NO ?' 
    END
FROM Customer
WHERE Email_Encrypted IS NOT NULL
ORDER BY CustomerID DESC;

CLOSE SYMMETRIC KEY VolleyballLeagueSymKey;
PRINT '';
GO


-- =============================================
-- STEP 12: Encryption Summary and Best Practices
-- =============================================
PRINT '========================================';
PRINT 'Encryption Summary';
PRINT '========================================';
PRINT '';
PRINT 'Encrypted Tables and Columns:';
PRINT '1. Customer Table:';
PRINT '   - Email_Encrypted (VARBINARY(256))';
PRINT '   - Phone_Encrypted (VARBINARY(128))';
PRINT '   - Street_Encrypted (VARBINARY(256))';
PRINT '';
PRINT '2. Coach Table:';
PRINT '   - Email_Encrypted (VARBINARY(256))';
PRINT '';
PRINT '3. Payment Table:';
PRINT '   - PaymentDetails_Encrypted (VARBINARY(512))';
PRINT '';
PRINT 'Encryption Method: AES_256 Symmetric Key Encryption';
PRINT 'Protected by: Certificate (VolleyballLeagueCert)';
PRINT 'Certificate Expiry: 2030-12-31';
PRINT '';
PRINT '========================================';
PRINT 'Security Best Practices';
PRINT '========================================';
PRINT '';
PRINT '1. Always open and close symmetric keys in the same session';
PRINT '2. Use stored procedures for all encrypted data operations';
PRINT '3. Never expose decrypted data in application logs';
PRINT '4. Regularly backup the certificate and master key';
PRINT '5. Implement proper access controls on encryption views';
PRINT '6. Monitor certificate expiration dates';
PRINT '7. Use TLS/SSL for data in transit';
PRINT '8. Consider implementing column-level permissions';
PRINT '';
GO

-- =============================================
-- STEP 13: Backup Certificate (Important!)
-- =============================================
PRINT '========================================';
PRINT 'Certificate Backup Instructions';
PRINT '========================================';
PRINT '';
PRINT 'CRITICAL: Backup your certificate and private key!';
PRINT '';
PRINT 'To backup certificate, run:';
PRINT 'BACKUP CERTIFICATE VolleyballLeagueCert';
PRINT '    TO FILE = ''C:\Backup\VolleyballLeagueCert.cer''';
PRINT '    WITH PRIVATE KEY (';
PRINT '        FILE = ''C:\Backup\VolleyballLeagueCert_PrivateKey.pvk'',';
PRINT '        ENCRYPTION BY PASSWORD = ''YourStrongBackupPassword123!''';
PRINT '    );';
PRINT '';
PRINT 'Store these files in a secure location!';
PRINT '';
GO

-- =============================================
-- View Encryption Status
-- =============================================
PRINT '========================================';
PRINT 'Encryption Objects Status';
PRINT '========================================';
PRINT '';

-- Master Key
SELECT 
    'Database Master Key' AS ObjectType,
    CASE WHEN EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
         THEN 'EXISTS' ELSE 'NOT FOUND' END AS Status;

-- Certificate
SELECT 
    'Certificate' AS ObjectType,
    name AS ObjectName,
    pvt_key_encryption_type_desc AS EncryptionType,
    expiry_date AS ExpiryDate
FROM sys.certificates
WHERE name = 'VolleyballLeagueCert';

-- Symmetric Key
SELECT 
    'Symmetric Key' AS ObjectType,
    name AS ObjectName,
    algorithm_desc AS Algorithm,
    key_length AS KeyLength
FROM sys.symmetric_keys
WHERE name = 'VolleyballLeagueSymKey';

PRINT '';
PRINT '========================================';
PRINT 'Encryption Script Completed Successfully!';
PRINT '========================================';
PRINT '';
PRINT 'Summary:';
PRINT '- Database Master Key: Created';
PRINT '- Certificate: Created (Expires 2030-12-31)';
PRINT '- Symmetric Key: Created (AES_256)';
PRINT '- Encrypted Columns: 6 total across 3 tables';
PRINT '- Secure Views: 3 created';
PRINT '- Secure Procedures: 2 created';
PRINT '- Utility Functions: 1 created';
PRINT '';
PRINT 'REMEMBER: Backup your certificate and private key!';
PRINT '========================================';
GO