-- =============================================
-- Volleyball League Database - DDL Script
-- =============================================

-- Drop and Create Database
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'VolleyballLeague')
BEGIN
    ALTER DATABASE VolleyballLeague SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE VolleyballLeague;
END
GO

CREATE DATABASE VolleyballLeague;
GO

USE VolleyballLeague;
GO

-- =============================================
-- Drop existing objects if they exist
-- =============================================
IF OBJECT_ID('dbo.Refund', 'U') IS NOT NULL DROP TABLE dbo.Refund;
IF OBJECT_ID('dbo.Payment', 'U') IS NOT NULL DROP TABLE dbo.Payment;
IF OBJECT_ID('dbo.Ticket', 'U') IS NOT NULL DROP TABLE dbo.Ticket;
IF OBJECT_ID('dbo.[Order]', 'U') IS NOT NULL DROP TABLE dbo.[Order];
IF OBJECT_ID('dbo.Customer', 'U') IS NOT NULL DROP TABLE dbo.Customer;
IF OBJECT_ID('dbo.Record', 'U') IS NOT NULL DROP TABLE dbo.Record;
IF OBJECT_ID('dbo.PlayerStats', 'U') IS NOT NULL DROP TABLE dbo.PlayerStats;
IF OBJECT_ID('dbo.Player_Historic_Stats', 'U') IS NOT NULL DROP TABLE dbo.Player_Historic_Stats;
IF OBJECT_ID('dbo.MatchTeamAssign', 'U') IS NOT NULL DROP TABLE dbo.MatchTeamAssign;
IF OBJECT_ID('dbo.StrategyPlan', 'U') IS NOT NULL DROP TABLE dbo.StrategyPlan;
IF OBJECT_ID('dbo.CoachAssign', 'U') IS NOT NULL DROP TABLE dbo.CoachAssign;
IF OBJECT_ID('dbo.PlayerAssign', 'U') IS NOT NULL DROP TABLE dbo.PlayerAssign;
IF OBJECT_ID('dbo.Match', 'U') IS NOT NULL DROP TABLE dbo.Match;
IF OBJECT_ID('dbo.Queue', 'U') IS NOT NULL DROP TABLE dbo.Queue;
IF OBJECT_ID('dbo.VIP_Seat', 'U') IS NOT NULL DROP TABLE dbo.VIP_Seat;
IF OBJECT_ID('dbo.CourtSide_Seat', 'U') IS NOT NULL DROP TABLE dbo.CourtSide_Seat;
IF OBJECT_ID('dbo.Seat', 'U') IS NOT NULL DROP TABLE dbo.Seat;
IF OBJECT_ID('dbo.Section', 'U') IS NOT NULL DROP TABLE dbo.Section;
IF OBJECT_ID('dbo.Indoor_Venue', 'U') IS NOT NULL DROP TABLE dbo.Indoor_Venue;
IF OBJECT_ID('dbo.Outdoor_Venue', 'U') IS NOT NULL DROP TABLE dbo.Outdoor_Venue;
IF OBJECT_ID('dbo.Venue', 'U') IS NOT NULL DROP TABLE dbo.Venue;
IF OBJECT_ID('dbo.Team_Historic_Stats', 'U') IS NOT NULL DROP TABLE dbo.Team_Historic_Stats;
IF OBJECT_ID('dbo.Team', 'U') IS NOT NULL DROP TABLE dbo.Team;
IF OBJECT_ID('dbo.Season', 'U') IS NOT NULL DROP TABLE dbo.Season;
IF OBJECT_ID('dbo.Coach', 'U') IS NOT NULL DROP TABLE dbo.Coach;
IF OBJECT_ID('dbo.Player', 'U') IS NOT NULL DROP TABLE dbo.Player;
IF OBJECT_ID('dbo.Referee', 'U') IS NOT NULL DROP TABLE dbo.Referee;
IF OBJECT_ID('dbo.Tournament', 'U') IS NOT NULL DROP TABLE dbo.Tournament;
GO

-- =============================================
-- Create Tables
-- =============================================

-- CUSTOMER Table
CREATE TABLE dbo.Customer (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(25) NOT NULL,
    LastName VARCHAR(25) NOT NULL,
    Email VARCHAR(255) NOT NULL UNIQUE,
    Phone VARCHAR(15) NULL,
    Street VARCHAR(200) NULL,
    City VARCHAR(200) NULL,
    StateProvince VARCHAR(100) NULL,
    Country VARCHAR(100) NULL,
    ZipCode CHAR(9) NULL,
    CONSTRAINT CHK_Customer_Email CHECK (Email LIKE '%@%.%')
);

-- TOURNAMENT Table
CREATE TABLE dbo.Tournament (
    TournamentID INT IDENTITY(1,1) PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    CONSTRAINT CHK_Tournament_Dates CHECK (EndDate >= StartDate)
);

-- VENUE Table
CREATE TABLE dbo.Venue (
    VenueID INT IDENTITY(1,1) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    StreetAddress VARCHAR(200) NULL,
    City VARCHAR(100) NOT NULL,
    StateProvince VARCHAR(100) NULL,
    Country VARCHAR(100) NOT NULL,
    ZipCode VARCHAR(20) NULL,
    NumberOfCourts INT NOT NULL,
    SeatingCapacity INT NOT NULL,
    StandingCapacity INT NOT NULL,
    TimeZone VARCHAR(50) NOT NULL,
    CONSTRAINT CHK_Venue_Courts CHECK (NumberOfCourts > 0),
    CONSTRAINT CHK_Venue_Capacity CHECK (SeatingCapacity >= 0 AND StandingCapacity >= 0)
);

-- OUTDOOR_VENUE Table (Subtype)
CREATE TABLE dbo.Outdoor_Venue (
    OutdoorVenueID INT PRIMARY KEY,
    SurfaceType VARCHAR(20) NOT NULL,
    HasLighting BIT NOT NULL DEFAULT 0,
    DrainageSystem BIT NOT NULL DEFAULT 0,
    HasWeatherProtection BIT NOT NULL DEFAULT 0,
    CONSTRAINT FK_OutdoorVenue_Venue FOREIGN KEY (OutdoorVenueID) REFERENCES Venue(VenueID),

    CONSTRAINT CHK_Outdoor_SurfaceType 
        CHECK (SurfaceType IN ('Grass', 'Clay', 'Hard', 'Synthetic', 'Sand', 'Artificial Turf')),
    CONSTRAINT CHK_Outdoor_Lighting 
        CHECK (HasLighting IN (0, 1)),
    CONSTRAINT CHK_Outdoor_Drainage 
        CHECK (DrainageSystem IN (0, 1))
);

-- INDOOR_VENUE Table (Subtype)
CREATE TABLE dbo.Indoor_Venue (
    IndoorVenueID INT PRIMARY KEY,  -- inherits from Venue
    FloorType VARCHAR(30) NOT NULL,
    CeilingHeight DECIMAL(4,1) NOT NULL,  -- e.g., height in feet or meters
    HasAirConditioning BIT NOT NULL DEFAULT 0,
    CONSTRAINT FK_IndoorVenue_Venue FOREIGN KEY (IndoorVenueID) REFERENCES dbo.Venue(VenueID),
    
    CONSTRAINT CHK_Indoor_FloorType 
        CHECK (FloorType IN ('Hardwood', 'Sport Court', 'Rubber', 'Concrete', 'Synthetic')),
    CONSTRAINT CHK_Indoor_CeilingHeight 
        CHECK (CeilingHeight BETWEEN 8.0 AND 25.0),
    CONSTRAINT CHK_Indoor_AirConditioning 
        CHECK (HasAirConditioning IN (0, 1))
);

-- SECTION Table
CREATE TABLE dbo.Section (
    SectionID INT IDENTITY(1,1) PRIMARY KEY,
    VenueID INT NOT NULL,
    Name VARCHAR(50) NOT NULL,
    SeatingCapacity INT NOT NULL,
    StandingCapacity INT NOT NULL DEFAULT 0,
    WheelChairAccessibleSeats INT DEFAULT 0,
    DistanceToCourtMeters DECIMAL(6,2) NOT NULL DEFAULT 0.0,
    CONSTRAINT FK_Section_Venue FOREIGN KEY (VenueID) REFERENCES Venue(VenueID),

    CONSTRAINT CHK_Section_SeatingCapacity CHECK (SeatingCapacity >= 0),
    CONSTRAINT CHK_Section_StandingCapacity CHECK (StandingCapacity >= 0),
    CONSTRAINT CHK_Section_WheelchairSeats CHECK (WheelChairAccessibleSeats >= 0),
    CONSTRAINT CHK_Section_Distance CHECK (DistanceToCourtMeters >= 0)
);

-- SEAT Table
CREATE TABLE dbo.Seat (
    SeatID INT IDENTITY(1,1) PRIMARY KEY,
    SectionID INT NOT NULL,
    SeatNumber VARCHAR(50) NOT NULL,
    RowNumber VARCHAR(10) NULL,
    SeatLetter VARCHAR(5) NULL,
    IsAccessible BIT NOT NULL DEFAULT 0, 
    Status VARCHAR(20) NOT NULL DEFAULT 'Available',
    BasePrice DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_Seat_Section FOREIGN KEY (SectionID) REFERENCES Section(SectionID),
    CONSTRAINT CHK_Seat_Price CHECK (BasePrice >= 0),
    CONSTRAINT CHK_Seat_Status CHECK (Status IN ('Available','Reserved','Sold')),
    CONSTRAINT CHK_Seat_Accessible CHECK (IsAccessible IN (0,1))
);

-- VIP_SEAT Table (Subtype)
CREATE TABLE dbo.VIP_Seat (
    VIP_SeatID INT PRIMARY KEY,
    Benefit VARCHAR(500) NULL,
    LoungeAccess BIT NOT NULL DEFAULT 0,
    PriorityEntry BIT NOT NULL DEFAULT 0,
    CONSTRAINT FK_VIPSeat_Seat FOREIGN KEY (VIP_SeatID) REFERENCES Seat(SeatID),
    CONSTRAINT CHK_VIP_LoungeAccess CHECK (LoungeAccess IN (0,1)),
    CONSTRAINT CHK_VIP_PriorityEntry CHECK (PriorityEntry IN (0,1))
);

-- COURTSIDE_SEAT Table (Subtype)
CREATE TABLE dbo.CourtSide_Seat (
    CourtSide_SeatID INT PRIMARY KEY,
    EnhancedViewingAngle BIT NOT NULL DEFAULT 0,
    ReservedForMedia BIT NOT NULL DEFAULT 0,
    ProximityToCourt DECIMAL(5,2) NOT NULL,
    CONSTRAINT FK_CourtsideSeat_Seat FOREIGN KEY (CourtSide_SeatID) REFERENCES Seat(SeatID),
    CONSTRAINT CHK_Courtside_Enhanced CHECK (EnhancedViewingAngle IN (0,1)),
    CONSTRAINT CHK_Courtside_Reserved CHECK (ReservedForMedia IN (0,1)),
    CONSTRAINT CHK_Courtside_Proximity CHECK (ProximityToCourt >= 0)
);

-- REFEREE Table
CREATE TABLE dbo.Referee (
    Referee_ID INT IDENTITY(1,1) PRIMARY KEY,
    Referee_Name VARCHAR(50) NOT NULL,
    RefereeDOB DATE,
    WorkStartDate DATE
);

-- PLAYER Table
CREATE TABLE dbo.Player (
    PlayerID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    BirthDate DATE NOT NULL,
    PreferredPosition VARCHAR(20) NOT NULL
        CHECK (PreferredPosition IN ('Outside Hitter', 'Setter', 'Middle Blocker', 'Libero', 'Opposite Hitter'))
);

-- COACH Table
CREATE TABLE dbo.Coach (
    CoachID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(25) NOT NULL,
    LastName VARCHAR(25) NOT NULL,
    YearsOfExperience INT NOT NULL CHECK (YearsOfExperience >= 0),
    Email VARCHAR(255) NOT NULL UNIQUE
);

-- SEASON Table
CREATE TABLE dbo.Season (
    SeasonID INT IDENTITY(1,1) PRIMARY KEY,
    SeasonName VARCHAR(50) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    OrganizerName VARCHAR(500) NULL,
    SponsorName VARCHAR(500) NULL,
    CONSTRAINT CHK_Season_Dates CHECK (EndDate >= StartDate)
);

-- TEAM Table
CREATE TABLE dbo.Team (
    TeamID INT IDENTITY(1,1) PRIMARY KEY,
    TeamName VARCHAR(50) NOT NULL,
    TeamColor VARCHAR(30) NULL,
    PlayersGender VARCHAR(10) NULL CHECK (PlayersGender IN ('Male','Female','Coed')),
    TeamFoundedYear INT NULL CHECK (TeamFoundedYear >= 1800 AND TeamFoundedYear <= YEAR(GETDATE()))
);

-- TEAM_HISTORIC_STATS Table
CREATE TABLE dbo.Team_Historic_Stats (
    TeamID INT NOT NULL,
    DataUpdateDate DATE NOT NULL,
    TotalLoss INT NOT NULL DEFAULT 0 CHECK (TotalLoss >= 0),
    TotalWins INT NOT NULL DEFAULT 0 CHECK (TotalWins >= 0),
    TotalDraws INT NOT NULL DEFAULT 0 CHECK (TotalDraws >= 0),
    TotalPoints INT NOT NULL DEFAULT 0 CHECK (TotalPoints >= 0),
    RankingPosition INT NOT NULL CHECK (RankingPosition > 0),
    RankingPoints DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (RankingPoints >= 0),
    PRIMARY KEY (TeamID, DataUpdateDate),
    CONSTRAINT FK_TeamStats_Team FOREIGN KEY (TeamID) REFERENCES Team(TeamID)
);

-- QUEUE Table
CREATE TABLE dbo.Queue (
    QueueID INT IDENTITY(1,1) PRIMARY KEY,
    HomeTeam_ID INT NOT NULL,
    AwayTeam_ID INT NOT NULL,
    VenueID INT NOT NULL,
    TournamentID INT NOT NULL,
    SchedulingPriority INT NOT NULL DEFAULT 1 CHECK (SchedulingPriority > 0),
    Status VARCHAR(50) NOT NULL DEFAULT 'Pending',
    ScheduledTime DATETIME NULL,
    CONSTRAINT FK_Queue_HomeTeam FOREIGN KEY (HomeTeam_ID) REFERENCES Team(TeamID),
    CONSTRAINT FK_Queue_AwayTeam FOREIGN KEY (AwayTeam_ID) REFERENCES Team(TeamID),
    CONSTRAINT FK_Queue_Venue FOREIGN KEY (VenueID) REFERENCES Venue(VenueID),
    CONSTRAINT FK_Queue_Tournament FOREIGN KEY (TournamentID) REFERENCES Tournament(TournamentID),
    CONSTRAINT CHK_Queue_DifferentTeams CHECK (HomeTeam_ID <> AwayTeam_ID)
);

-- MATCH Table
CREATE TABLE dbo.Match (
    MatchID INT IDENTITY(1,1) PRIMARY KEY,
    QueueID INT NOT NULL,
    HomeTeam_ID INT NOT NULL,
    AwayTeam_ID INT NOT NULL,
    WinningTeam_ID INT NULL, 
    MatchDuration TIME NULL,
    Score VARCHAR(20) NULL,
    Comments VARCHAR(500) NULL,
    SetDifferential INT NULL,
    PointDifferential INT NULL,
    CONSTRAINT FK_Match_Queue FOREIGN KEY (QueueID) 
        REFERENCES Queue(QueueID),
    CONSTRAINT FK_Match_HomeTeam FOREIGN KEY (HomeTeam_ID) REFERENCES Team(TeamID),
    CONSTRAINT FK_Match_AwayTeam FOREIGN KEY (AwayTeam_ID) REFERENCES Team(TeamID),
    CONSTRAINT FK_Match_WinningTeam FOREIGN KEY (WinningTeam_ID) REFERENCES Team(TeamID),
    CONSTRAINT CHK_Match_DifferentTeams CHECK (HomeTeam_ID <> AwayTeam_ID),
    CONSTRAINT CHK_WinningTeam_Valid CHECK (
        WinningTeam_ID IS NULL OR WinningTeam_ID IN (HomeTeam_ID, AwayTeam_ID)
    )
);

-- RECORD Table
CREATE TABLE dbo.Record (
    Record_ID INT IDENTITY(1,1) PRIMARY KEY,
    Referee_ID INT NOT NULL,
    MatchID INT NOT NULL,
    RecordType VARCHAR(30) NOT NULL,
    RecordStatus VARCHAR(20) NOT NULL DEFAULT 'Pending',
    Severity VARCHAR(20) NOT NULL DEFAULT 'Normal',  
    CONSTRAINT FK_Record_Referee FOREIGN KEY (Referee_ID) REFERENCES Referee(Referee_ID),
    CONSTRAINT FK_Record_Match FOREIGN KEY (MatchID) REFERENCES Match(MatchID)
);

-- PLAYERSTATS Table
CREATE TABLE dbo.PlayerStats (
    PlayerSTATSID INT IDENTITY(1,1) PRIMARY KEY,
    MatchID INT NOT NULL,
    PlayerID INT NOT NULL,
    Kills INT NOT NULL DEFAULT 0,
    Assists INT NOT NULL DEFAULT 0,
    Aces INT NOT NULL DEFAULT 0,
    Blocks INT NOT NULL DEFAULT 0,
    CONSTRAINT FK_PlayerStats_Match FOREIGN KEY (MatchID) REFERENCES Match(MatchID),
    CONSTRAINT FK_PlayerStats_Player FOREIGN KEY (PlayerID) REFERENCES Player(PlayerID),
    CONSTRAINT CHK_PlayerStats_Positive CHECK (Kills >= 0 AND Assists >= 0 AND Aces >= 0 AND Blocks >= 0)
);

-- PLAYER_HISTORIC_STATS Table
CREATE TABLE dbo.Player_Historic_Stats (
    PlayerID INT NOT NULL,
    DataUpdateDate DATE NOT NULL,
    TotalWins INT NOT NULL DEFAULT 0 CHECK (TotalWins >= 0),
    TotalLosses INT NOT NULL DEFAULT 0 CHECK (TotalLosses >= 0),
    TotalDraws INT NOT NULL DEFAULT 0 CHECK (TotalDraws >= 0),
    TotalPoints INT NOT NULL DEFAULT 0 CHECK (TotalPoints >= 0),
    RankingPosition INT NOT NULL CHECK (RankingPosition > 0),
    RankingPoints DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (RankingPoints >= 0),
    PRIMARY KEY (PlayerID, DataUpdateDate),
    CONSTRAINT FK_PlayerHistoricStats_Player FOREIGN KEY (PlayerID) 
        REFERENCES Player(PlayerID)
);

-- MATCHTEAMASSIGN Table
CREATE TABLE dbo.MatchTeamAssign (
    AssignID INT IDENTITY(1,1) PRIMARY KEY,
    MatchID INT NOT NULL,
    PlayerID INT NOT NULL,
    HomeTeamID INT NOT NULL,
    AwayTeamID INT NOT NULL,
    StartTime DATETIME NOT NULL,
    EndTime DATETIME NOT NULL,
    Role VARCHAR(50)  NOT NULL,
    PlayerPosition VARCHAR(30),
    CONSTRAINT FK_MTA_Match FOREIGN KEY (MatchID) REFERENCES Match(MatchID),
    CONSTRAINT FK_MTA_Player FOREIGN KEY (PlayerID) REFERENCES Player(PlayerID),
    CONSTRAINT FK_MTA_HomeTeam FOREIGN KEY (HomeTeamID) REFERENCES Team(TeamID),
    CONSTRAINT FK_MTA_AwayTeam FOREIGN KEY (AwayTeamID) REFERENCES Team(TeamID),
    CONSTRAINT CHK_MTA_DifferentTeams CHECK (HomeTeamID <> AwayTeamID),
    CONSTRAINT CHK_MTA_StartEndTime CHECK (EndTime >= StartTime)
);

-- STRATEGYPLAN Table
CREATE TABLE dbo.StrategyPlan (
    StrategyPlanID INT IDENTITY(1,1) PRIMARY KEY,
    TeamID INT NOT NULL,
    MatchID INT NOT NULL,
    OpponentTeamID INT NOT NULL,
    KeyFactors VARCHAR(500) NOT NULL DEFAULT '',
    TargetedWeaknesses VARCHAR(500) NOT NULL DEFAULT '',
    OurStrengths VARCHAR(500) NOT NULL DEFAULT '',
    CONSTRAINT FK_Strategy_Team FOREIGN KEY (TeamID) REFERENCES Team(TeamID),
    CONSTRAINT FK_Strategy_Match FOREIGN KEY (MatchID) REFERENCES Match(MatchID),
    CONSTRAINT FK_Strategy_OpponentTeam FOREIGN KEY (OpponentTeamID) REFERENCES Team(TeamID),
    CONSTRAINT CHK_Strategy_DifferentTeams CHECK (TeamID <> OpponentTeamID)
);

-- COACHASSIGN Table
CREATE TABLE dbo.CoachAssign (
    CoachAssignID INT IDENTITY(1,1) PRIMARY KEY,
    CoachID INT NOT NULL,
    TeamID INT NOT NULL,
    SeasonID INT NOT NULL,
    HireDate DATE NOT NULL,
    TerminateDate DATE NULL,
    CoachRole VARCHAR(50) NOT NULL,
    ContractType VARCHAR(30) NOT NULL DEFAULT 'Full-Time', 
    CONSTRAINT FK_CoachAssign_Coach FOREIGN KEY (CoachID) REFERENCES Coach(CoachID),
    CONSTRAINT FK_CoachAssign_Team FOREIGN KEY (TeamID) REFERENCES Team(TeamID),
    CONSTRAINT FK_CoachAssign_Season FOREIGN KEY (SeasonID) REFERENCES Season(SeasonID),
    CONSTRAINT CHK_CoachAssign_Dates CHECK (TerminateDate IS NULL OR TerminateDate >= HireDate)
);

-- PLAYERASSIGN Table
CREATE TABLE dbo.PlayerAssign (
    PlayerAssignID INT IDENTITY(1,1) PRIMARY KEY,
    PlayerID INT NOT NULL,
    TeamID INT NOT NULL,
    SeasonID INT NOT NULL,
    HireDate DATE NOT NULL,
    TerminateDate DATE NULL,
    Position VARCHAR(30) NOT NULL,
    CONSTRAINT FK_PlayerAssign_Player FOREIGN KEY (PlayerID) REFERENCES Player(PlayerID),
    CONSTRAINT FK_PlayerAssign_Team FOREIGN KEY (TeamID) REFERENCES Team(TeamID),
    CONSTRAINT FK_PlayerAssign_Season FOREIGN KEY (SeasonID) REFERENCES Season(SeasonID),
    CONSTRAINT CHK_PlayerAssign_Dates CHECK (TerminateDate IS NULL OR TerminateDate >= HireDate)
);

-- ORDER Table
CREATE TABLE dbo.[Order] (
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    OrderDate DATE NOT NULL DEFAULT GETDATE(),
    OrderStatus VARCHAR(20) NOT NULL DEFAULT 'Pending',
    GrandTotal DECIMAL(12,2) NOT NULL CHECK (GrandTotal >= 0),
    Tax DECIMAL(12,2) NOT NULL DEFAULT 0 CHECK (Tax >= 0),  
    CONSTRAINT FK_Order_Customer FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

-- PAYMENT Table
CREATE TABLE dbo.Payment (
    PaymentID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    Method VARCHAR(20) NOT NULL,
    Amount DECIMAL(12,2) NOT NULL,
    PaidAt DATE NOT NULL DEFAULT GETDATE(),
    Status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    CONSTRAINT FK_Payment_Order FOREIGN KEY (OrderID) REFERENCES [Order](OrderID),
    CONSTRAINT CHK_Payment_Amount CHECK (Amount > 0)
);

-- REFUND Table
CREATE TABLE dbo.Refund (
    RefundID INT IDENTITY(1,1) PRIMARY KEY,
    PaymentID INT NOT NULL,
    Amount DECIMAL(12,2) NOT NULL,
    Reason VARCHAR(200) NOT NULL,
    RefundedDate DATE NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Refund_Payment FOREIGN KEY (PaymentID) REFERENCES Payment(PaymentID),
    CONSTRAINT CHK_Refund_Amount CHECK (Amount > 0)
);

-- TICKET Table
CREATE TABLE dbo.Ticket (
    TicketID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    MatchID INT NOT NULL,
    SeatID INT NOT NULL,
    Barcode VARCHAR(128) NOT NULL UNIQUE,
    Status VARCHAR(20) NOT NULL DEFAULT 'Valid',
    UsedAt DATE NULL,
    TicketType VARCHAR(20) NOT NULL,
    DeliveryMethod VARCHAR(20) NOT NULL, 
    CONSTRAINT FK_Ticket_Order FOREIGN KEY (OrderID) REFERENCES [Order](OrderID),
    CONSTRAINT FK_Ticket_Match FOREIGN KEY (MatchID) REFERENCES Match(MatchID),
    CONSTRAINT FK_Ticket_Seat FOREIGN KEY (SeatID) REFERENCES Seat(SeatID)
);

GO

-- =============================================
-- Create Indexes for Performance
-- =============================================
CREATE INDEX IX_Customer_Email ON Customer(Email);
CREATE INDEX IX_Venue_City ON Venue(City);
CREATE INDEX IX_Match_Teams ON Match(HomeTeam_ID, AwayTeam_ID);
CREATE INDEX IX_Ticket_Match ON Ticket(MatchID);
CREATE INDEX IX_Queue_Tournament ON Queue(TournamentID);
CREATE INDEX IX_PlayerAssign_Season ON PlayerAssign(SeasonID);
CREATE INDEX IX_CoachAssign_Season ON CoachAssign(SeasonID);
GO

PRINT 'Database schema created successfully!';