-- =============================================
-- Volleyball League Database - PSM Script
-- Contains: Stored Procedures, Functions, Views, and Triggers
-- =============================================

USE VolleyballLeague;
GO

-- =============================================
-- SECTION 1: STORED PROCEDURES
-- =============================================

-- =============================================
-- Stored Procedure 1: Process Ticket Purchase
-- Description: Handles complete ticket purchase transaction with seat validation
-- Parameters: 
--   @CustomerID - ID of the customer
--   @MatchID - ID of the match
--   @SeatID - ID of the seat
--   @PaymentMethod - Payment method (Credit Card, Cash, etc.)
--   @TicketType - Type of ticket (VIP, Courtside, Standard)
--   @DeliveryMethod - Delivery method (Email, Mobile, Print)
--   @NewOrderID - OUTPUT parameter returning the created order ID
--   @NewTicketID - OUTPUT parameter returning the created ticket ID
-- =============================================
CREATE OR ALTER PROCEDURE usp_ProcessTicketPurchase
    @CustomerID INT,
    @MatchID INT,
    @SeatID INT,
    @PaymentMethod VARCHAR(20),
    @TicketType VARCHAR(20),
    @DeliveryMethod VARCHAR(20),
    @NewOrderID INT OUTPUT,
    @NewTicketID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;
    DECLARE @BasePrice DECIMAL(10,2);
    DECLARE @Tax DECIMAL(12,2);
    DECLARE @GrandTotal DECIMAL(12,2);
    DECLARE @SeatStatus VARCHAR(20);
    DECLARE @Barcode VARCHAR(128);
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Validate customer exists
        IF NOT EXISTS (SELECT 1 FROM Customer WHERE CustomerID = @CustomerID)
        BEGIN
            RAISERROR('Customer ID %d does not exist', 16, 1, @CustomerID);
        END
        
        -- Validate match exists
        IF NOT EXISTS (SELECT 1 FROM Match WHERE MatchID = @MatchID)
        BEGIN
            RAISERROR('Match ID %d does not exist', 16, 1, @MatchID);
        END
        
        -- Validate seat exists and check availability
        SELECT @BasePrice = BasePrice, @SeatStatus = Status
        FROM Seat
        WHERE SeatID = @SeatID;
        
        IF @BasePrice IS NULL
        BEGIN
            RAISERROR('Seat ID %d does not exist', 16, 1, @SeatID);
        END
        
        IF @SeatStatus <> 'Available'
        BEGIN
            RAISERROR('Seat ID %d is not available (Current status: %s)', 16, 1, @SeatID, @SeatStatus);
        END
        
        -- Calculate tax (8.5% tax rate)
        SET @Tax = @BasePrice * 0.085;
        SET @GrandTotal = @BasePrice + @Tax;
        
        -- Create Order
        INSERT INTO [Order] (CustomerID, OrderDate, OrderStatus, GrandTotal, Tax)
        VALUES (@CustomerID, GETDATE(), 'Completed', @GrandTotal, @Tax);
        
        SET @NewOrderID = SCOPE_IDENTITY();
        
        -- Create Payment
        INSERT INTO Payment (OrderID, Method, Amount, PaidAt, Status)
        VALUES (@NewOrderID, @PaymentMethod, @GrandTotal, GETDATE(), 'Completed');
        
        -- Generate unique barcode
        SET @Barcode = 'BAR' + 
                      RIGHT('000000' + CAST(@NewOrderID AS VARCHAR(6)), 6) + 
                      'M' + RIGHT('000' + CAST(@MatchID AS VARCHAR(3)), 3) + 
                      'S' + RIGHT('000' + CAST(@SeatID AS VARCHAR(3)), 3);
        
        -- Create Ticket
        INSERT INTO Ticket (OrderID, MatchID, SeatID, Barcode, Status, UsedAt, TicketType, DeliveryMethod)
        VALUES (@NewOrderID, @MatchID, @SeatID, @Barcode, 'Valid', NULL, @TicketType, @DeliveryMethod);
        
        SET @NewTicketID = SCOPE_IDENTITY();
        
        -- Update seat status to Sold
        UPDATE Seat
        SET Status = 'Sold'
        WHERE SeatID = @SeatID;
        
        COMMIT TRANSACTION;
        
        PRINT 'Ticket purchase completed successfully.';
        PRINT 'Order ID: ' + CAST(@NewOrderID AS VARCHAR(10));
        PRINT 'Ticket ID: ' + CAST(@NewTicketID AS VARCHAR(10));
        PRINT 'Barcode: ' + @Barcode;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        SET @ErrorMessage = ERROR_MESSAGE();
        SET @ErrorSeverity = ERROR_SEVERITY();
        SET @ErrorState = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
        RETURN -1;
    END CATCH
    
    RETURN 0;
END;
GO

-- =============================================
-- Stored Procedure 2: Update Match Results
-- Description: Updates match results and player statistics
-- Parameters:
--   @MatchID - ID of the match
--   @WinningTeamID - ID of the winning team
--   @Score - Match score
--   @MatchDuration - Duration of match
--   @Comments - Match comments
-- =============================================
CREATE OR ALTER PROCEDURE usp_UpdateMatchResults
    @MatchID INT,
    @WinningTeamID INT,
    @Score VARCHAR(20),
    @MatchDuration TIME,
    @Comments VARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;
    DECLARE @HomeTeamID INT;
    DECLARE @AwayTeamID INT;
    DECLARE @SetDiff INT;
    DECLARE @PointDiff INT;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Get home and away team IDs
        SELECT @HomeTeamID = HomeTeam_ID, @AwayTeamID = AwayTeam_ID
        FROM Match
        WHERE MatchID = @MatchID;
        
        IF @HomeTeamID IS NULL
        BEGIN
            RAISERROR('Match ID %d does not exist', 16, 1, @MatchID);
        END
        
        -- Validate winning team
        IF @WinningTeamID NOT IN (@HomeTeamID, @AwayTeamID)
        BEGIN
            RAISERROR('Winning team ID %d must be either home team (%d) or away team (%d)', 
                     16, 1, @WinningTeamID, @HomeTeamID, @AwayTeamID);
        END
        
        -- Parse score to calculate differentials (assuming format like "3-1")
        DECLARE @WinnerSets INT, @LoserSets INT;
        SET @WinnerSets = CAST(LEFT(@Score, CHARINDEX('-', @Score) - 1) AS INT);
        SET @LoserSets = CAST(RIGHT(@Score, LEN(@Score) - CHARINDEX('-', @Score)) AS INT);
        SET @SetDiff = @WinnerSets - @LoserSets;
        
        -- Estimate point differential (rough estimate: 5 points per set difference)
        SET @PointDiff = @SetDiff * 5 + (RAND() * 20 - 10);
        
        -- Update match results
        UPDATE Match
        SET WinningTeam_ID = @WinningTeamID,
            Score = @Score,
            MatchDuration = @MatchDuration,
            Comments = @Comments,
            SetDifferential = @SetDiff,
            PointDifferential = @PointDiff
        WHERE MatchID = @MatchID;
        
        -- Update team statistics
        DECLARE @UpdateDate DATE = GETDATE();
        
        -- Update winning team stats
        IF EXISTS (SELECT 1 FROM Team_Historic_Stats WHERE TeamID = @WinningTeamID AND DataUpdateDate = @UpdateDate)
        BEGIN
            UPDATE Team_Historic_Stats
            SET TotalWins = TotalWins + 1,
                TotalPoints = TotalPoints + 3
            WHERE TeamID = @WinningTeamID AND DataUpdateDate = @UpdateDate;
        END
        ELSE
        BEGIN
            INSERT INTO Team_Historic_Stats (TeamID, DataUpdateDate, TotalWins, TotalLoss, TotalDraws, TotalPoints, RankingPosition, RankingPoints)
            SELECT TeamID, @UpdateDate, TotalWins + 1, TotalLoss, TotalDraws, TotalPoints + 3, RankingPosition, RankingPoints + 5.0
            FROM Team_Historic_Stats
            WHERE TeamID = @WinningTeamID
            AND DataUpdateDate = (SELECT MAX(DataUpdateDate) FROM Team_Historic_Stats WHERE TeamID = @WinningTeamID);
        END
        
        -- Update losing team stats
        DECLARE @LosingTeamID INT = CASE WHEN @WinningTeamID = @HomeTeamID THEN @AwayTeamID ELSE @HomeTeamID END;
        
        IF EXISTS (SELECT 1 FROM Team_Historic_Stats WHERE TeamID = @LosingTeamID AND DataUpdateDate = @UpdateDate)
        BEGIN
            UPDATE Team_Historic_Stats
            SET TotalLoss = TotalLoss + 1
            WHERE TeamID = @LosingTeamID AND DataUpdateDate = @UpdateDate;
        END
        ELSE
        BEGIN
            INSERT INTO Team_Historic_Stats (TeamID, DataUpdateDate, TotalWins, TotalLoss, TotalDraws, TotalPoints, RankingPosition, RankingPoints)
            SELECT TeamID, @UpdateDate, TotalWins, TotalLoss + 1, TotalDraws, TotalPoints, RankingPosition, RankingPoints - 2.0
            FROM Team_Historic_Stats
            WHERE TeamID = @LosingTeamID
            AND DataUpdateDate = (SELECT MAX(DataUpdateDate) FROM Team_Historic_Stats WHERE TeamID = @LosingTeamID);
        END
        
        COMMIT TRANSACTION;
        
        PRINT 'Match results updated successfully.';
        PRINT 'Match ID: ' + CAST(@MatchID AS VARCHAR(10));
        PRINT 'Winner: Team ' + CAST(@WinningTeamID AS VARCHAR(10));
        PRINT 'Score: ' + @Score;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        SET @ErrorMessage = ERROR_MESSAGE();
        SET @ErrorSeverity = ERROR_SEVERITY();
        SET @ErrorState = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
        RETURN -1;
    END CATCH
    
    RETURN 0;
END;
GO

-- =============================================
-- Stored Procedure 3: Process Refund
-- Description: Processes refund for a ticket and updates seat availability
-- Parameters:
--   @PaymentID - ID of the payment to refund
--   @RefundAmount - Amount to refund
--   @RefundReason - Reason for refund
--   @NewRefundID - OUTPUT parameter returning the created refund ID
-- =============================================
CREATE OR ALTER PROCEDURE usp_ProcessRefund
    @PaymentID INT,
    @RefundAmount DECIMAL(12,2),
    @RefundReason VARCHAR(200),
    @NewRefundID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;
    DECLARE @PaymentAmount DECIMAL(12,2);
    DECLARE @OrderID INT;
    DECLARE @SeatID INT;
    DECLARE @TicketID INT;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Validate payment exists and get amount
        SELECT @PaymentAmount = Amount, @OrderID = OrderID
        FROM Payment
        WHERE PaymentID = @PaymentID;
        
        IF @PaymentAmount IS NULL
        BEGIN
            RAISERROR('Payment ID %d does not exist', 16, 1, @PaymentID);
        END
        
        -- Validate refund amount
        IF @RefundAmount > @PaymentAmount
        BEGIN
            -- œ»ππΩ®¥ÌŒÛœ˚œ¢,»ª∫Û≈◊≥ˆ
            SET @ErrorMessage = 'Refund amount ($' + CAST(@RefundAmount AS VARCHAR(20)) + 
                               ') cannot exceed payment amount ($' + CAST(@PaymentAmount AS VARCHAR(20)) + ')';
            RAISERROR(@ErrorMessage, 16, 1);
        END
        
        IF @RefundAmount <= 0
        BEGIN
            RAISERROR('Refund amount must be greater than zero', 16, 1);
        END
        
        -- Create refund record
        INSERT INTO Refund (PaymentID, Amount, Reason, RefundedDate)
        VALUES (@PaymentID, @RefundAmount, @RefundReason, GETDATE());
        
        SET @NewRefundID = SCOPE_IDENTITY();
        
        -- Get ticket and seat information
        SELECT TOP 1 @TicketID = TicketID, @SeatID = SeatID
        FROM Ticket
        WHERE OrderID = @OrderID;
        
        -- If full refund, cancel ticket and make seat available
        IF @RefundAmount = @PaymentAmount
        BEGIN
            UPDATE Ticket
            SET Status = 'Cancelled'
            WHERE OrderID = @OrderID;
            
            UPDATE Seat
            SET Status = 'Available'
            WHERE SeatID = @SeatID;
            
            UPDATE [Order]
            SET OrderStatus = 'Refunded'
            WHERE OrderID = @OrderID;
            
            UPDATE Payment
            SET Status = 'Refunded'
            WHERE PaymentID = @PaymentID;
            
            PRINT 'Full refund processed. Ticket cancelled and seat made available.';
        END
        ELSE
        BEGIN
            PRINT 'Partial refund processed. Ticket remains valid.';
        END
        
        COMMIT TRANSACTION;
        
        PRINT 'Refund processed successfully.';
        PRINT 'Refund ID: ' + CAST(@NewRefundID AS VARCHAR(10));
        PRINT 'Refund Amount: $' + CAST(@RefundAmount AS VARCHAR(20));
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        SET @ErrorMessage = ERROR_MESSAGE();
        SET @ErrorSeverity = ERROR_SEVERITY();
        SET @ErrorState = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
        RETURN -1;
    END CATCH
    
    RETURN 0;
END;
GO

-- =============================================
-- SECTION 2: USER-DEFINED FUNCTIONS
-- =============================================

-- =============================================
-- Function 1: Calculate Player Performance Score
-- Description: Calculates a performance score based on player statistics
-- Parameters: @PlayerID - ID of the player
-- Returns: Performance score (DECIMAL)
-- =============================================
CREATE OR ALTER FUNCTION dbo.fn_CalculatePlayerPerformanceScore
(
    @PlayerID INT
)
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @PerformanceScore DECIMAL(10,2);
    
    SELECT @PerformanceScore = 
        (SUM(Kills) * 3.0 +          -- Kills weighted heavily
         SUM(Assists) * 2.0 +        -- Assists important
         SUM(Aces) * 4.0 +           -- Aces very valuable
         SUM(Blocks) * 2.5) /        -- Blocks valuable
        CASE WHEN COUNT(*) = 0 THEN 1 ELSE COUNT(*) END  -- Average per match
    FROM PlayerStats
    WHERE PlayerID = @PlayerID;
    
    -- If no stats found, return 0
    IF @PerformanceScore IS NULL
        SET @PerformanceScore = 0;
    
    RETURN @PerformanceScore;
END;
GO

-- =============================================
-- Function 2: Get Team Win Percentage
-- Description: Calculates win percentage for a team
-- Parameters: @TeamID - ID of the team
-- Returns: Win percentage (DECIMAL)
-- =============================================
CREATE OR ALTER FUNCTION dbo.fn_GetTeamWinPercentage
(
    @TeamID INT
)
RETURNS DECIMAL(5,2)
AS
BEGIN
    DECLARE @WinPercentage DECIMAL(5,2);
    DECLARE @TotalWins INT;
    DECLARE @TotalGames INT;
    
    SELECT TOP 1
        @TotalWins = TotalWins,
        @TotalGames = TotalWins + TotalLoss + TotalDraws
    FROM Team_Historic_Stats
    WHERE TeamID = @TeamID
    ORDER BY DataUpdateDate DESC;
    
    IF @TotalGames = 0 OR @TotalGames IS NULL
        SET @WinPercentage = 0;
    ELSE
        SET @WinPercentage = (@TotalWins * 100.0) / @TotalGames;
    
    RETURN @WinPercentage;
END;
GO

-- =============================================
-- Function 3: Get Venue Utilization Rate
-- Description: Calculates how many seats are sold vs capacity
-- Parameters: @VenueID - ID of the venue
-- Returns: Utilization percentage (DECIMAL)
-- =============================================
CREATE OR ALTER FUNCTION dbo.fn_GetVenueUtilizationRate
(
    @VenueID INT
)
RETURNS DECIMAL(5,2)
AS
BEGIN
    DECLARE @UtilizationRate DECIMAL(5,2);
    DECLARE @TotalSeats INT;
    DECLARE @SoldSeats INT;
    
    SELECT @TotalSeats = COUNT(*)
    FROM Seat s
    INNER JOIN Section sec ON s.SectionID = sec.SectionID
    WHERE sec.VenueID = @VenueID;
    
    SELECT @SoldSeats = COUNT(*)
    FROM Seat s
    INNER JOIN Section sec ON s.SectionID = sec.SectionID
    WHERE sec.VenueID = @VenueID
    AND s.Status = 'Sold';
    
    IF @TotalSeats = 0 OR @TotalSeats IS NULL
        SET @UtilizationRate = 0;
    ELSE
        SET @UtilizationRate = (@SoldSeats * 100.0) / @TotalSeats;
    
    RETURN @UtilizationRate;
END;
GO

-- =============================================
-- SECTION 3: VIEWS
-- =============================================

-- =============================================
-- View 1: Match Schedule Report
-- Description: Comprehensive view of scheduled matches with venue and team details
-- =============================================
CREATE OR ALTER VIEW vw_MatchScheduleReport
AS
SELECT 
    m.MatchID,
    q.ScheduledTime,
    ht.TeamName AS HomeTeam,
    at.TeamName AS AwayTeam,
    v.Name AS VenueName,
    v.City AS VenueCity,
    t.Name AS TournamentName,
    m.Score,
    m.MatchDuration,
    CASE 
        WHEN m.WinningTeam_ID = m.HomeTeam_ID THEN ht.TeamName
        WHEN m.WinningTeam_ID = m.AwayTeam_ID THEN at.TeamName
        ELSE 'TBD'
    END AS Winner,
    q.Status AS MatchStatus,
    m.Comments
FROM Match m
INNER JOIN Queue q ON m.QueueID = q.QueueID
INNER JOIN Team ht ON m.HomeTeam_ID = ht.TeamID
INNER JOIN Team at ON m.AwayTeam_ID = at.TeamID
INNER JOIN Venue v ON q.VenueID = v.VenueID
INNER JOIN Tournament t ON q.TournamentID = t.TournamentID;
GO

-- =============================================
-- View 2: Player Performance Summary
-- Description: Summary of player statistics and performance
-- =============================================
CREATE OR ALTER VIEW vw_PlayerPerformanceSummary
AS
SELECT 
    p.PlayerID,
    p.FirstName,
    p.LastName,
    p.PreferredPosition,
    COUNT(DISTINCT ps.MatchID) AS MatchesPlayed,
    SUM(ps.Kills) AS TotalKills,
    SUM(ps.Assists) AS TotalAssists,
    SUM(ps.Aces) AS TotalAces,
    SUM(ps.Blocks) AS TotalBlocks,
    CAST(AVG(CAST(ps.Kills AS DECIMAL(10,2))) AS DECIMAL(10,2)) AS AvgKills,
    CAST(AVG(CAST(ps.Assists AS DECIMAL(10,2))) AS DECIMAL(10,2)) AS AvgAssists,
    CAST(AVG(CAST(ps.Aces AS DECIMAL(10,2))) AS DECIMAL(10,2)) AS AvgAces,
    CAST(AVG(CAST(ps.Blocks AS DECIMAL(10,2))) AS DECIMAL(10,2)) AS AvgBlocks,
    dbo.fn_CalculatePlayerPerformanceScore(p.PlayerID) AS PerformanceScore,
    phs.RankingPosition,
    phs.RankingPoints
FROM Player p
LEFT JOIN PlayerStats ps ON p.PlayerID = ps.PlayerID
LEFT JOIN (
    SELECT PlayerID, RankingPosition, RankingPoints
    FROM Player_Historic_Stats phs1
    WHERE DataUpdateDate = (
        SELECT MAX(DataUpdateDate) 
        FROM Player_Historic_Stats phs2 
        WHERE phs2.PlayerID = phs1.PlayerID
    )
) phs ON p.PlayerID = phs.PlayerID
GROUP BY 
    p.PlayerID, p.FirstName, p.LastName, p.PreferredPosition,
    phs.RankingPosition, phs.RankingPoints;
GO

-- =============================================
-- View 3: Revenue Report by Match
-- Description: Financial summary of ticket sales by match
-- =============================================
CREATE OR ALTER VIEW vw_RevenueReportByMatch
AS
SELECT 
    m.MatchID,
    q.ScheduledTime AS MatchDate,
    ht.TeamName AS HomeTeam,
    at.TeamName AS AwayTeam,
    v.Name AS VenueName,
    COUNT(DISTINCT t.TicketID) AS TicketsSold,
    SUM(o.GrandTotal) AS TotalRevenue,
    SUM(o.Tax) AS TotalTax,
    SUM(o.GrandTotal - o.Tax) AS NetRevenue,
    AVG(o.GrandTotal) AS AvgTicketPrice,
    COUNT(DISTINCT CASE WHEN t.TicketType = 'VIP' THEN t.TicketID END) AS VIPTickets,
    COUNT(DISTINCT CASE WHEN t.TicketType = 'Courtside' THEN t.TicketID END) AS CourtsideTickets,
    COUNT(DISTINCT CASE WHEN t.TicketType = 'Standard' THEN t.TicketID END) AS StandardTickets
FROM Match m
INNER JOIN Queue q ON m.QueueID = q.QueueID
INNER JOIN Team ht ON m.HomeTeam_ID = ht.TeamID
INNER JOIN Team at ON m.AwayTeam_ID = at.TeamID
INNER JOIN Venue v ON q.VenueID = v.VenueID
LEFT JOIN Ticket t ON m.MatchID = t.MatchID
LEFT JOIN [Order] o ON t.OrderID = o.OrderID
WHERE t.Status <> 'Cancelled' OR t.Status IS NULL
GROUP BY 
    m.MatchID, q.ScheduledTime, ht.TeamName, at.TeamName, v.Name;
GO

-- =============================================
-- SECTION 4: TRIGGERS
-- =============================================

-- =============================================
-- Trigger 1: Audit Trail for Customer Updates
-- Description: Logs all changes to customer information
-- =============================================

-- First, create audit table
IF OBJECT_ID('dbo.CustomerAudit', 'U') IS NOT NULL 
    DROP TABLE dbo.CustomerAudit;
GO

CREATE TABLE dbo.CustomerAudit (
    AuditID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    ActionType VARCHAR(10) NOT NULL,
    OldFirstName VARCHAR(25),
    NewFirstName VARCHAR(25),
    OldLastName VARCHAR(25),
    NewLastName VARCHAR(25),
    OldEmail VARCHAR(255),
    NewEmail VARCHAR(255),
    OldPhone VARCHAR(15),
    NewPhone VARCHAR(15),
    ModifiedBy VARCHAR(100) DEFAULT SYSTEM_USER,
    ModifiedDate DATETIME DEFAULT GETDATE()
);
GO

-- Create the trigger
CREATE OR ALTER TRIGGER trg_CustomerAudit
ON dbo.Customer
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO CustomerAudit (
        CustomerID, ActionType, 
        OldFirstName, NewFirstName,
        OldLastName, NewLastName,
        OldEmail, NewEmail,
        OldPhone, NewPhone,
        ModifiedBy, ModifiedDate
    )
    SELECT 
        d.CustomerID,
        'UPDATE',
        d.FirstName, i.FirstName,
        d.LastName, i.LastName,
        d.Email, i.Email,
        d.Phone, i.Phone,
        SYSTEM_USER,
        GETDATE()
    FROM deleted d
    INNER JOIN inserted i ON d.CustomerID = i.CustomerID
    WHERE 
        d.FirstName <> i.FirstName OR
        d.LastName <> i.LastName OR
        d.Email <> i.Email OR
        ISNULL(d.Phone, '') <> ISNULL(i.Phone, '');
END;
GO

-- =============================================
-- Test Scripts for Stored Procedures
-- =============================================

PRINT '';
PRINT '========================================';
PRINT 'Testing Stored Procedures';
PRINT '========================================';
PRINT '';

-- Test 1: Process Ticket Purchase
PRINT 'Test 1: Process Ticket Purchase';
DECLARE @OrderID INT, @TicketID INT;
DECLARE @AvailableSeatID INT;

-- ≤È’““ª∏ˆø…”√µƒ◊˘Œª
SELECT TOP 1 @AvailableSeatID = SeatID 
FROM Seat 
WHERE Status = 'Available'
ORDER BY SeatID;

-- »Áπ˚√ª”–ø…”√◊˘Œª,÷ÿ÷√◊˘Œª27
IF @AvailableSeatID IS NULL
BEGIN
    PRINT 'No available seats found. Resetting Seat 27 for testing...';
    UPDATE Seat SET Status = 'Available' WHERE SeatID = 27;
    SET @AvailableSeatID = 27;
END

PRINT 'Using Seat ID: ' + CAST(@AvailableSeatID AS VARCHAR(10));

EXEC usp_ProcessTicketPurchase 
    @CustomerID = 1,
    @MatchID = 1,
    @SeatID = @AvailableSeatID,
    @PaymentMethod = 'Credit Card',
    @TicketType = 'Standard',
    @DeliveryMethod = 'Email',
    @NewOrderID = @OrderID OUTPUT,
    @NewTicketID = @TicketID OUTPUT;
PRINT '';

-- Test 2: Update Match Results
PRINT 'Test 2: Update Match Results';
EXEC usp_UpdateMatchResults
    @MatchID = 1,
    @WinningTeamID = 1,
    @Score = '3-2',
    @MatchDuration = '02:15:00',
    @Comments = 'Updated: Exciting five-set match';
PRINT '';

-- Test 3: Process Refund (using the order just created)
PRINT 'Test 3: Process Refund';
DECLARE @RefundID INT;
DECLARE @TestPaymentID INT;
SELECT TOP 1 @TestPaymentID = PaymentID FROM Payment ORDER BY PaymentID DESC;

IF @TestPaymentID IS NOT NULL
BEGIN
    EXEC usp_ProcessRefund
        @PaymentID = @TestPaymentID,
        @RefundAmount = 50.00,
        @RefundReason = 'Test partial refund',
        @NewRefundID = @RefundID OUTPUT;
END
ELSE
BEGIN
    PRINT 'No payment found for refund test';
END
PRINT '';

-- =============================================
-- Test Scripts for Functions
-- =============================================

PRINT '========================================';
PRINT 'Testing User-Defined Functions';
PRINT '========================================';
PRINT '';

-- Test Function 1: Calculate Player Performance Score
PRINT 'Test Function 1: Player Performance Scores';
SELECT TOP 5
    PlayerID,
    FirstName,
    LastName,
    dbo.fn_CalculatePlayerPerformanceScore(PlayerID) AS PerformanceScore
FROM Player
ORDER BY dbo.fn_CalculatePlayerPerformanceScore(PlayerID) DESC;
PRINT '';

-- Test Function 2: Get Team Win Percentage
PRINT 'Test Function 2: Team Win Percentages';
SELECT TOP 5
    TeamID,
    TeamName,
    dbo.fn_GetTeamWinPercentage(TeamID) AS WinPercentage
FROM Team
ORDER BY dbo.fn_GetTeamWinPercentage(TeamID) DESC;
PRINT '';

-- Test Function 3: Get Venue Utilization Rate
PRINT 'Test Function 3: Venue Utilization Rates';
SELECT TOP 5
    VenueID,
    Name,
    dbo.fn_GetVenueUtilizationRate(VenueID) AS UtilizationRate
FROM Venue
ORDER BY dbo.fn_GetVenueUtilizationRate(VenueID) DESC;
PRINT '';

-- =============================================
-- Test Scripts for Views
-- =============================================

PRINT '========================================';
PRINT 'Testing Views';
PRINT '========================================';
PRINT '';

-- Test View 1: Match Schedule Report
PRINT 'Test View 1: Match Schedule Report (Top 5 matches)';
SELECT TOP 5 * FROM vw_MatchScheduleReport ORDER BY ScheduledTime;
PRINT '';

-- Test View 2: Player Performance Summary
PRINT 'Test View 2: Player Performance Summary (Top 5 performers)';
SELECT TOP 5 * FROM vw_PlayerPerformanceSummary ORDER BY PerformanceScore DESC;
PRINT '';

-- Test View 3: Revenue Report by Match
PRINT 'Test View 3: Revenue Report by Match (Top 5 by revenue)';
SELECT TOP 5 * FROM vw_RevenueReportByMatch ORDER BY TotalRevenue DESC;
PRINT '';

-- =============================================
-- Test Trigger
-- =============================================

PRINT '========================================';
PRINT 'Testing Trigger';
PRINT '========================================';
PRINT '';

PRINT 'Test Trigger: Update Customer Information';
-- Update a customer to test the audit trigger
UPDATE Customer
SET Phone = '555-9999', Email = 'newemail@test.com'
WHERE CustomerID = 1;

-- View audit log
PRINT 'Audit Log Entries:';
SELECT * FROM CustomerAudit;
PRINT '';

PRINT '========================================';
PRINT 'PSM Script Completed Successfully!';
PRINT '========================================';