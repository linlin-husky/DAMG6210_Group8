-- =============================================
-- Volleyball League Database - Complete Data Insertion Script
-- =============================================

USE VolleyballLeague;
GO

-- =============================================
-- Part 1: Base Tables (Independent tables)
-- =============================================

-- CUSTOMER Table (15 rows)
INSERT INTO Customer (FirstName, LastName, Email, Phone, Street, City, StateProvince, Country, ZipCode) VALUES
('John', 'Smith', 'john.smith@email.com', '555-0101', '123 Main St', 'Boston', 'MA', 'USA', '021011234'),
('Emma', 'Johnson', 'emma.j@email.com', '555-0102', '456 Oak Ave', 'Cambridge', 'MA', 'USA', '021381234'),
('Michael', 'Williams', 'mwilliams@email.com', '555-0103', '789 Pine Rd', 'Somerville', 'MA', 'USA', '021431234'),
('Sarah', 'Brown', 'sbrown@email.com', '555-0104', '321 Elm St', 'Brookline', 'MA', 'USA', '024451234'),
('David', 'Jones', 'djones@email.com', '555-0105', '654 Maple Dr', 'Newton', 'MA', 'USA', '024581234'),
('Lisa', 'Garcia', 'lgarcia@email.com', '555-0106', '987 Cedar Ln', 'Quincy', 'MA', 'USA', '021691234'),
('James', 'Miller', 'jmiller@email.com', '555-0107', '147 Birch St', 'Waltham', 'MA', 'USA', '024511234'),
('Jennifer', 'Davis', 'jdavis@email.com', '555-0108', '258 Spruce Ave', 'Medford', 'MA', 'USA', '021551234'),
('Robert', 'Rodriguez', 'rrodriguez@email.com', '555-0109', '369 Ash Rd', 'Malden', 'MA', 'USA', '021481234'),
('Maria', 'Martinez', 'mmartinez@email.com', '555-0110', '741 Willow Way', 'Revere', 'MA', 'USA', '021511234'),
('William', 'Hernandez', 'whernandez@email.com', '555-0111', '852 Cherry Ct', 'Chelsea', 'MA', 'USA', '021501234'),
('Patricia', 'Lopez', 'plopez@email.com', '555-0112', '963 Poplar Pl', 'Everett', 'MA', 'USA', '021491234'),
('Charles', 'Gonzalez', 'cgonzalez@email.com', '555-0113', '159 Hickory Hl', 'Lynn', 'MA', 'USA', '019011234'),
('Linda', 'Wilson', 'lwilson@email.com', '555-0114', '357 Walnut St', 'Salem', 'MA', 'USA', '019701234'),
('Thomas', 'Anderson', 'tanderson@email.com', '555-0115', '753 Beech Blvd', 'Peabody', 'MA', 'USA', '019601234');

PRINT 'Customer data inserted: 15 rows';

-- TOURNAMENT Table (10 rows)
INSERT INTO Tournament (Name, StartDate, EndDate) VALUES
('Spring Championship 2025', '2025-03-01', '2025-03-31'),
('Summer League Finals', '2025-06-15', '2025-07-15'),
('Fall Classic Tournament', '2025-09-10', '2025-10-10'),
('Winter Invitational', '2025-12-01', '2025-12-20'),
('Regional Qualifiers East', '2025-04-05', '2025-04-25'),
('Regional Qualifiers West', '2025-04-05', '2025-04-25'),
('National Championship', '2025-08-01', '2025-08-30'),
('Youth Development Cup', '2025-05-10', '2025-05-30'),
('Veterans Memorial Series', '2025-11-01', '2025-11-15'),
('International Friendship Games', '2025-07-20', '2025-08-05');

PRINT 'Tournament data inserted: 10 rows';

-- REFEREE Table (12 rows)
INSERT INTO Referee (Referee_Name, RefereeDOB, WorkStartDate) VALUES
('Alex Thompson', '1985-03-15', '2010-01-15'),
('Maria Rodriguez', '1988-07-22', '2012-06-01'),
('James Wilson', '1982-11-08', '2008-03-20'),
('Sophie Chen', '1990-05-14', '2015-09-01'),
('Marcus Johnson', '1987-09-30', '2011-04-15'),
('Emily Davis', '1989-12-05', '2013-08-10'),
('Carlos Martinez', '1984-02-18', '2009-05-22'),
('Anna Kowalski', '1991-06-25', '2016-01-05'),
('David Kim', '1986-08-12', '2010-10-30'),
('Rachel Green', '1992-04-03', '2017-02-14'),
('Thomas Anderson', '1983-10-20', '2007-11-12'),
('Jessica Taylor', '1988-01-28', '2012-07-18');

PRINT 'Referee data inserted: 12 rows';

-- PLAYER Table (30 rows)
INSERT INTO Player (FirstName, LastName, BirthDate, PreferredPosition) VALUES
('Tyler', 'Jackson', '2000-01-15', 'Outside Hitter'),
('Olivia', 'White', '1998-03-22', 'Setter'),
('Ethan', 'Harris', '1999-05-10', 'Middle Blocker'),
('Sophia', 'Martin', '2001-07-18', 'Libero'),
('Noah', 'Thompson', '1997-09-25', 'Opposite Hitter'),
('Ava', 'Garcia', '2000-11-30', 'Outside Hitter'),
('Liam', 'Martinez', '1998-02-14', 'Middle Blocker'),
('Isabella', 'Robinson', '1999-04-08', 'Setter'),
('Mason', 'Clark', '2001-06-20', 'Libero'),
('Mia', 'Lewis', '1997-08-12', 'Opposite Hitter'),
('Lucas', 'Lee', '2000-10-05', 'Outside Hitter'),
('Charlotte', 'Walker', '1998-12-28', 'Middle Blocker'),
('Alexander', 'Hall', '1999-01-16', 'Setter'),
('Amelia', 'Allen', '2001-03-09', 'Libero'),
('Daniel', 'Young', '1997-05-22', 'Outside Hitter'),
('Emily', 'King', '2000-07-14', 'Opposite Hitter'),
('Matthew', 'Wright', '1998-09-03', 'Middle Blocker'),
('Abigail', 'Lopez', '1999-11-27', 'Setter'),
('Jackson', 'Hill', '2001-02-19', 'Outside Hitter'),
('Harper', 'Scott', '1997-04-11', 'Libero'),
('Sebastian', 'Green', '2000-06-08', 'Opposite Hitter'),
('Evelyn', 'Adams', '1998-08-26', 'Middle Blocker'),
('Aiden', 'Baker', '1999-10-15', 'Setter'),
('Elizabeth', 'Nelson', '2001-12-03', 'Outside Hitter'),
('Michael', 'Carter', '1997-01-29', 'Libero'),
('Sofia', 'Mitchell', '2000-03-17', 'Opposite Hitter'),
('Benjamin', 'Perez', '1998-05-21', 'Middle Blocker'),
('Victoria', 'Roberts', '1999-07-09', 'Setter'),
('Jacob', 'Turner', '2001-09-12', 'Outside Hitter'),
('Grace', 'Phillips', '1997-11-24', 'Libero');

PRINT 'Player data inserted: 30 rows';

-- PLAYER_HISTORIC_STATS Table (30 rows - one for each player)
INSERT INTO Player_Historic_Stats (PlayerID, DataUpdateDate, TotalWins, TotalLosses, TotalDraws, TotalPoints, RankingPosition, RankingPoints) VALUES
(1, '2025-01-31', 12, 5, 1, 37, 5, 88.5),
(2, '2025-01-31', 15, 3, 2, 47, 1, 95.8),
(3, '2025-01-31', 10, 7, 1, 31, 8, 82.3),
(4, '2025-01-31', 14, 4, 2, 44, 2, 92.7),
(5, '2025-01-31', 11, 6, 1, 34, 6, 85.1),
(6, '2025-01-31', 13, 5, 2, 41, 4, 89.9),
(7, '2025-01-31', 9, 8, 1, 28, 12, 78.4),
(8, '2025-01-31', 14, 4, 2, 44, 3, 91.2),
(9, '2025-01-31', 8, 9, 1, 25, 15, 74.6),
(10, '2025-01-31', 12, 6, 2, 38, 7, 86.8),
(11, '2025-01-31', 10, 7, 1, 31, 9, 81.5),
(12, '2025-01-31', 11, 6, 1, 34, 10, 83.9),
(13, '2025-01-31', 13, 5, 2, 41, 11, 88.2),
(14, '2025-01-31', 7, 10, 1, 22, 18, 71.3),
(15, '2025-01-31', 15, 3, 2, 47, 13, 94.1),
(16, '2025-01-31', 9, 8, 1, 28, 14, 79.7),
(17, '2025-01-31', 12, 5, 1, 37, 16, 87.4),
(18, '2025-01-31', 8, 9, 1, 25, 17, 75.8),
(19, '2025-01-31', 10, 7, 1, 31, 19, 80.9),
(20, '2025-01-31', 6, 11, 1, 19, 20, 68.5),
(21, '2025-01-31', 11, 6, 1, 34, 21, 84.3),
(22, '2025-01-31', 13, 5, 2, 41, 22, 90.6),
(23, '2025-01-31', 9, 8, 1, 28, 23, 77.2),
(24, '2025-01-31', 14, 4, 2, 44, 24, 93.5),
(25, '2025-01-31', 7, 10, 1, 22, 25, 70.1),
(26, '2025-01-31', 12, 6, 2, 38, 26, 85.7),
(27, '2025-01-31', 10, 7, 1, 31, 27, 82.9),
(28, '2025-01-31', 15, 3, 2, 47, 28, 96.2),
(29, '2025-01-31', 8, 9, 1, 25, 29, 73.8),
(30, '2025-01-31', 11, 6, 1, 34, 30, 86.1);

PRINT 'Player_Historic_Stats data inserted: 30 rows';

-- COACH Table (15 rows)
INSERT INTO Coach (FirstName, LastName, YearsOfExperience, Email) VALUES
('Robert', 'Stevens', 15, 'rstevens@coaches.com'),
('Michelle', 'Parker', 12, 'mparker@coaches.com'),
('Frank', 'Morrison', 20, 'fmorrison@coaches.com'),
('Linda', 'Cooper', 8, 'lcooper@coaches.com'),
('George', 'Bennett', 18, 'gbennett@coaches.com'),
('Nancy', 'Foster', 10, 'nfoster@coaches.com'),
('Kevin', 'Ross', 14, 'kross@coaches.com'),
('Sandra', 'Powell', 11, 'spowell@coaches.com'),
('Brian', 'Hughes', 16, 'bhughes@coaches.com'),
('Karen', 'Ward', 9, 'kward@coaches.com'),
('Steven', 'Brooks', 13, 'sbrooks@coaches.com'),
('Angela', 'Reed', 7, 'areed@coaches.com'),
('Paul', 'Cook', 19, 'pcook@coaches.com'),
('Dorothy', 'Morgan', 10, 'dmorgan@coaches.com'),
('Mark', 'Bell', 12, 'mbell@coaches.com');

PRINT 'Coach data inserted: 15 rows';

-- SEASON Table (10 rows)
INSERT INTO Season (SeasonName, StartDate, EndDate, OrganizerName, SponsorName) VALUES
('Spring 2025', '2025-03-01', '2025-05-31', 'New England Volleyball Association', 'SportGear Inc'),
('Summer 2025', '2025-06-01', '2025-08-31', 'New England Volleyball Association', 'Athletic Apparel Co'),
('Fall 2024', '2024-09-01', '2024-11-30', 'New England Volleyball Association', 'Fitness First'),
('Winter 2024-2025', '2024-12-01', '2025-02-28', 'New England Volleyball Association', 'Sports Equipment Ltd'),
('Spring 2024', '2024-03-01', '2024-05-31', 'New England Volleyball Association', 'Champion Sports'),
('Summer 2024', '2024-06-01', '2024-08-31', 'New England Volleyball Association', 'ProVolley Brands'),
('Fall 2025', '2025-09-01', '2025-11-30', 'New England Volleyball Association', 'Elite Athletics'),
('Youth Spring 2025', '2025-03-15', '2025-05-15', 'Youth Volleyball Federation', 'Junior Sports Inc'),
('Veterans Fall 2025', '2025-09-15', '2025-11-15', 'Senior Sports League', 'Legacy Fitness'),
('International 2025', '2025-07-01', '2025-08-15', 'Global Volleyball Federation', 'WorldSport Brands');

PRINT 'Season data inserted: 10 rows';
PRINT 'Part 1 completed successfully!';
GO

-- =============================================
-- Part 2: Venue and Team Tables
-- =============================================

SET IDENTITY_INSERT Venue ON;

-- VENUE Table (20 rows)
INSERT INTO Venue (VenueID, Name, StreetAddress, City, StateProvince, Country, ZipCode, NumberOfCourts, SeatingCapacity, StandingCapacity, TimeZone) VALUES
(1, 'Boston Sports Arena', '100 Arena Way', 'Boston', 'MA', 'USA', '02101', 4, 5000, 1000, 'EST'),
(2, 'Cambridge Community Center', '200 College Rd', 'Cambridge', 'MA', 'USA', '02138', 2, 2000, 500, 'EST'),
(3, 'Newton Volleyball Complex', '300 Sports Pkwy', 'Newton', 'MA', 'USA', '02458', 6, 8000, 2000, 'EST'),
(4, 'Quincy Beach Courts', '400 Beach St', 'Quincy', 'MA', 'USA', '02169', 8, 3000, 3000, 'EST'),
(5, 'Waltham Indoor Facility', '500 Indoor Ln', 'Waltham', 'MA', 'USA', '02451', 3, 3500, 800, 'EST'),
(6, 'Salem Outdoor Complex', '600 Ocean Ave', 'Salem', 'MA', 'USA', '01970', 10, 2500, 4000, 'EST'),
(7, 'Lynn Sports Center', '700 Center Dr', 'Lynn', 'MA', 'USA', '01901', 4, 4000, 1200, 'EST'),
(8, 'Peabody Athletic Arena', '800 Athletic Way', 'Peabody', 'MA', 'USA', '01960', 3, 3000, 700, 'EST'),
(9, 'Brookline Recreation Hall', '900 Recreation Rd', 'Brookline', 'MA', 'USA', '02445', 2, 1500, 400, 'EST'),
(10, 'Somerville Sports Plaza', '1000 Plaza Blvd', 'Somerville', 'MA', 'USA', '02143', 5, 6000, 1500, 'EST'),
(11, 'Malden Multi-Court Center', '1100 Court St', 'Malden', 'MA', 'USA', '02148', 4, 3500, 900, 'EST'),
(12, 'Revere Beachside Arena', '1200 Beachside Dr', 'Revere', 'MA', 'USA', '02151', 6, 4500, 2500, 'EST'),
(13, 'Medford Field House', '1300 Academy St', 'Medford', 'MA', 'USA', '02155', 3, 2500, 600, 'EST'),
(14, 'Chelsea Sports Pavilion', '1400 Harbor Rd', 'Chelsea', 'MA', 'USA', '02150', 2, 1800, 450, 'EST'),
(15, 'Everett Performance Center', '1500 Broadway', 'Everett', 'MA', 'USA', '02149', 4, 3200, 900, 'EST'),
(16, 'Danvers Court Hub', '1600 Maple Ave', 'Danvers', 'MA', 'USA', '01923', 3, 2200, 500, 'EST'),
(17, 'Beverly Shore Courts', '1700 Shore Dr', 'Beverly', 'MA', 'USA', '01915', 6, 2000, 3500, 'EST'),
(18, 'Woburn Park Grounds', '1800 Park Ln', 'Woburn', 'MA', 'USA', '01801', 5, 1800, 3000, 'EST'),
(19, 'Melrose Community Fields', '1900 Community Rd', 'Melrose', 'MA', 'USA', '02176', 4, 1600, 2800, 'EST'),
(20, 'Stoneham Lakeside Courts', '2000 Lakeside Dr', 'Stoneham', 'MA', 'USA', '02180', 6, 2100, 3200, 'EST');

SET IDENTITY_INSERT Venue OFF;

PRINT 'Venue data inserted: 20 rows';

-- OUTDOOR_VENUE Table (6 rows)
INSERT INTO Outdoor_Venue (OutdoorVenueID, SurfaceType, HasLighting, DrainageSystem, HasWeatherProtection) VALUES
(4, 'Sand', 1, 1, 0),
(6, 'Grass', 1, 1, 1),
(12, 'Sand', 1, 1, 0),
(9, 'Artificial Turf', 0, 1, 0),
(10, 'Sand', 1, 1, 1),
(11, 'Grass', 1, 1, 0),
(17, 'Sand', 1, 1, 0),
(18, 'Grass', 1, 1, 0),
(19, 'Artificial Turf', 1, 1, 1),
(20, 'Sand', 1, 1, 1);

PRINT 'Outdoor_Venue data inserted: 10 rows';

-- INDOOR_VENUE Table (6 rows)
INSERT INTO Indoor_Venue (IndoorVenueID, FloorType, CeilingHeight, HasAirConditioning) VALUES
(1, 'Hardwood', 12.5, 1),
(2, 'Sport Court', 10.0, 1),
(3, 'Hardwood', 15.0, 1),
(5, 'Rubber', 11.0, 1),
(7, 'Hardwood', 13.0, 1),
(8, 'Sport Court', 12.0, 1),
(13, 'Hardwood',   12.0, 1),
(14, 'Sport Court',11.5, 1),
(15, 'Rubber',     13.5, 1),
(16, 'Hardwood',   14.0, 1);

PRINT 'Indoor_Venue data inserted: 10 rows';

SET IDENTITY_INSERT Team ON;

-- TEAM Table (20 rows)
INSERT INTO Team (TeamID, TeamName, TeamColor, PlayersGender, TeamFoundedYear) VALUES
(1, 'Boston Spikers', 'Navy Blue', 'Coed', 2015),
(2, 'Cambridge Crushers', 'Crimson Red', 'Coed', 2017),
(3, 'Newton Knights', 'Royal Purple', 'Male', 2014),
(4, 'Quincy Waves', 'Ocean Blue', 'Female', 2016),
(5, 'Waltham Warriors', 'Forest Green', 'Coed', 2018),
(6, 'Salem Strikers', 'Bright Orange', 'Male', 2015),
(7, 'Lynn Lightning', 'Electric Yellow', 'Female', 2019),
(8, 'Peabody Panthers', 'Midnight Black', 'Coed', 2016),
(9, 'Brookline Blazers', 'Fire Red', 'Male', 2017),
(10, 'Somerville Slammers', 'Steel Gray', 'Female', 2018),
(11, 'Malden Mavericks', 'Sky Blue', 'Coed', 2019),
(12, 'Revere Rockets', 'Sunset Orange', 'Male', 2020),
(13, 'Medford Meteors', 'Deep Purple', 'Female', 2016),
(14, 'Chelsea Champions', 'Golden Yellow', 'Coed', 2017),
(15, 'Everett Eagles', 'Dark Green', 'Male', 2015),
(16, 'Danvers Dragons', 'Crimson', 'Female', 2018),
(17, 'Beverly Beasts', 'Royal Blue', 'Coed', 2019),
(18, 'Woburn Wolves', 'Silver Gray', 'Male', 2020),
(19, 'Melrose Mustangs', 'Maroon', 'Female', 2016),
(20, 'Stoneham Storm', 'Teal', 'Coed', 2017);

SET IDENTITY_INSERT Team OFF;

PRINT 'Team data inserted: 20 rows';

-- TEAM_HISTORIC_STATS Table (20 rows)
INSERT INTO Team_Historic_Stats (TeamID, DataUpdateDate, TotalLoss, TotalWins, TotalDraws, TotalPoints, RankingPosition, RankingPoints) VALUES
(1, '2025-01-31', 5, 16, 1, 49, 1, 95.5),
(2, '2025-01-31', 7, 14, 1, 43, 3, 88.2),
(3, '2025-01-31', 6, 15, 1, 46, 2, 92.1),
(4, '2025-01-31', 9, 12, 1, 37, 5, 82.5),
(5, '2025-01-31', 8, 13, 1, 40, 4, 85.8),
(6, '2025-01-31', 11, 10, 1, 31, 8, 75.3),
(7, '2025-01-31', 10, 11, 1, 34, 6, 80.6),
(8, '2025-01-31', 11, 10, 1, 31, 7, 77.9),
(9, '2025-01-31', 12, 9, 1, 28, 10, 70.2),
(10, '2025-01-31', 12, 9, 1, 28, 9, 83.4),
(11, '2025-01-31', 13, 8, 1, 25, 15, 62.1),
(12, '2025-01-31', 13, 8, 1, 25, 11, 86.7),
(13, '2025-01-31', 13, 8, 1, 25, 14, 65.8),
(14, '2025-01-31', 13, 8, 1, 25, 12, 78.5),
(15, '2025-01-31', 13, 8, 1, 25, 13, 81.2),
(16, '2025-01-31', 13, 8, 1, 25, 16, 84.9),
(17, '2025-01-31', 13, 8, 1, 25, 17, 76.4),
(18, '2025-01-31', 13, 8, 1, 25, 18, 82.8),
(19, '2025-01-31', 13, 8, 1, 25, 19, 73.6),
(20, '2025-01-31', 13, 8, 1, 25, 20, 79.1);

PRINT 'Team_Historic_Stats data inserted: 20 rows';
PRINT 'Part 2 completed successfully!';
GO

-- =============================================
-- Part 3: Section and Seat Tables
-- =============================================

-- SECTION Table (20 rows)
INSERT INTO Section (VenueID, Name, SeatingCapacity, StandingCapacity, WheelChairAccessibleSeats, DistanceToCourtMeters) VALUES
(1, 'Section A', 500, 100, 10, 5.5),
(1, 'Section B', 500, 100, 10, 8.0),
(1, 'Section C', 800, 200, 15, 12.0),
(2, 'Lower Bowl', 400, 100, 8, 6.0),
(2, 'Upper Deck', 600, 150, 5, 15.0),
(3, 'VIP Section', 300, 50, 12, 3.0),
(3, 'General Admission', 1200, 300, 20, 10.0),
(4, 'Beach Section A', 500, 500, 5, 8.0),
(4, 'Beach Section B', 500, 500, 5, 10.0),
(5, 'East Wing', 700, 150, 10, 7.0),
(5, 'West Wing', 700, 150, 10, 7.0),
(6, 'Outdoor Section 1', 400, 800, 6, 9.0),
(6, 'Outdoor Section 2', 400, 800, 6, 11.0),
(7, 'Main Court View', 800, 200, 15, 5.0),
(8, 'Center Section', 600, 120, 12, 6.5),
(9, 'Community Seating', 300, 80, 8, 8.5),
(10, 'Plaza North', 1000, 250, 18, 7.5),
(10, 'Plaza South', 1000, 250, 18, 7.5),
(11, 'Multi-Court East', 700, 180, 14, 6.0),
(12, 'Beachside Premium', 900, 500, 10, 4.5);

PRINT 'Section data inserted: 20 rows';

-- SEAT Table (50 rows)
DECLARE @i INT = 1;
DECLARE @sectionID INT;
DECLARE @rowNum VARCHAR(10);
DECLARE @seatLetter VARCHAR(5);

WHILE @i <= 50
BEGIN
    SET @sectionID = ((@i - 1) % 20) + 1;
    SET @rowNum = CAST(((@i - 1) / 5) + 1 AS VARCHAR(10));
    SET @seatLetter = CHAR(65 + ((@i - 1) % 5));
    
    INSERT INTO Seat (SectionID, SeatNumber, RowNumber, SeatLetter, IsAccessible, Status, BasePrice)
    VALUES (@sectionID, 'S' + CAST(@i AS VARCHAR(5)), @rowNum, @seatLetter, 
            CASE WHEN @i % 10 = 0 THEN 1 ELSE 0 END, 'Available', 
            CASE WHEN @sectionID <= 5 THEN 75.00 
                 WHEN @sectionID <= 10 THEN 50.00 
                 ELSE 35.00 END);
    
    SET @i = @i + 1;
END;

PRINT 'Seat data inserted: 50 rows';

-- VIP_SEAT Table (10 rows)
INSERT INTO VIP_Seat (VIP_SeatID, Benefit, LoungeAccess, PriorityEntry) VALUES
(1, 'Premium seating with complimentary refreshments', 1, 1),
(2, 'Meet and greet with players', 1, 1),
(6, 'VIP parking and early entry', 1, 1),
(11, 'Exclusive lounge access', 1, 1),
(16, 'Premium view with waiter service', 1, 1),
(21, 'Access to VIP lounge and priority entrance', 1, 1),
(26, 'Complimentary food and beverage', 1, 1),
(31, 'Post-game player interaction', 1, 1),
(36, 'Premium comfort seating', 1, 1),
(41, 'VIP merchandise package', 1, 1);

PRINT 'VIP_Seat data inserted: 10 rows';

-- COURTSIDE_SEAT Table (10 rows)
INSERT INTO CourtSide_Seat (CourtSide_SeatID, EnhancedViewingAngle, ReservedForMedia, ProximityToCourt) VALUES
(3, 1, 0, 2.5),
(8, 1, 1, 1.8),
(13, 1, 0, 2.0),
(18, 1, 1, 1.5),
(23, 1, 0, 2.2),
(28, 1, 0, 2.8),
(33, 1, 1, 1.9),
(38, 1, 0, 2.4),
(43, 1, 0, 2.6),
(48, 1, 1, 1.7);

PRINT 'CourtSide_Seat data inserted: 10 rows';
PRINT 'Part 3 completed successfully!';
GO

-- =============================================
-- Part 4: Queue, Match and Related Tables
-- =============================================

-- QUEUE Table (15 rows)
INSERT INTO Queue (HomeTeam_ID, AwayTeam_ID, VenueID, TournamentID, SchedulingPriority, Status, ScheduledTime) VALUES
(1, 2, 1, 1, 1, 'Scheduled', '2025-03-05 18:00:00'),
(3, 4, 3, 1, 2, 'Scheduled', '2025-03-06 19:00:00'),
(5, 6, 5, 2, 1, 'Scheduled', '2025-06-20 17:30:00'),
(7, 8, 7, 2, 2, 'Scheduled', '2025-06-22 18:30:00'),
(9, 10, 2, 3, 1, 'Scheduled', '2025-09-15 19:00:00'),
(11, 12, 4, 3, 2, 'Scheduled', '2025-09-17 17:00:00'),
(13, 14, 6, 4, 1, 'Scheduled', '2025-12-05 18:00:00'),
(15, 16, 8, 4, 2, 'Scheduled', '2025-12-07 19:30:00'),
(17, 18, 10, 5, 1, 'Scheduled', '2025-04-10 18:00:00'),
(19, 20, 11, 5, 2, 'Scheduled', '2025-04-12 17:30:00'),
(1, 3, 1, 6, 1, 'Scheduled', '2025-04-15 19:00:00'),
(2, 4, 3, 6, 2, 'Scheduled', '2025-04-17 18:30:00'),
(5, 7, 5, 7, 1, 'Scheduled', '2025-08-05 17:00:00'),
(6, 8, 7, 7, 2, 'Scheduled', '2025-08-08 19:00:00'),
(9, 11, 2, 8, 1, 'Scheduled', '2025-05-15 18:00:00');

PRINT 'Queue data inserted: 15 rows';

-- MATCH Table (15 rows)
INSERT INTO Match (QueueID, HomeTeam_ID, AwayTeam_ID, WinningTeam_ID, MatchDuration, Score, Comments, SetDifferential, PointDifferential) VALUES
(1, 1, 2, 1, '01:45:00', '3-1', 'Excellent match with great energy', 2, 15),
(2, 3, 4, 3, '02:10:00', '3-2', 'Very close and competitive', 1, 8),
(3, 5, 6, 6, '01:35:00', '3-0', 'Dominant performance by away team', 3, 22),
(4, 7, 8, 7, '01:55:00', '3-1', 'Strong home court advantage', 2, 12),
(5, 9, 10, 10, '02:05:00', '3-2', 'Thrilling five-set battle', 1, 5),
(6, 11, 12, 11, '01:40:00', '3-1', 'Solid team performance', 2, 18),
(7, 13, 14, 14, '01:50:00', '3-1', 'Away team showed great composure', 2, 14),
(8, 15, 16, 15, '02:15:00', '3-2', 'Epic comeback in final set', 1, 3),
(9, 17, 18, 17, '01:38:00', '3-0', 'Flawless execution', 3, 25),
(10, 19, 20, 20, '01:52:00', '3-1', 'Well-contested match', 2, 10),
(11, 1, 3, 1, '01:48:00', '3-1', 'Strong defensive play', 2, 16),
(12, 2, 4, 4, '02:00:00', '3-2', 'Intense final set', 1, 6),
(13, 5, 7, 5, '01:42:00', '3-0', 'Dominant serving', 3, 20),
(14, 6, 8, 8, '01:58:00', '3-2', 'Great rally exchanges', 1, 7),
(15, 9, 11, 9, '01:36:00', '3-0', 'Impressive blocking', 3, 19);

PRINT 'Match data inserted: 15 rows';

-- RECORD Table (25 rows)
INSERT INTO Record (Referee_ID, MatchID, RecordType, RecordStatus, Severity) VALUES
(1, 1, 'Yellow Card', 'Confirmed', 'Minor'),
(2, 1, 'Timeout', 'Confirmed', 'None'),
(3, 2, 'Red Card', 'Confirmed', 'Major'),
(4, 2, 'Substitution', 'Confirmed', 'None'),
(5, 3, 'Challenge', 'Confirmed', 'Minor'),
(6, 3, 'Timeout', 'Confirmed', 'None'),
(7, 4, 'Yellow Card', 'Confirmed', 'Minor'),
(8, 4, 'Injury Timeout', 'Confirmed', 'Moderate'),
(9, 5, 'Challenge', 'Overturned', 'Minor'),
(10, 5, 'Timeout', 'Confirmed', 'None'),
(11, 6, 'Substitution', 'Confirmed', 'None'),
(12, 6, 'Yellow Card', 'Confirmed', 'Minor'),
(1, 7, 'Timeout', 'Confirmed', 'None'),
(2, 8, 'Challenge', 'Confirmed', 'Minor'),
(3, 9, 'Red Card', 'Confirmed', 'Major'),
(4, 10, 'Substitution', 'Confirmed', 'None'),
(5, 11, 'Timeout', 'Confirmed', 'None'),
(6, 12, 'Yellow Card', 'Confirmed', 'Minor'),
(7, 13, 'Challenge', 'Confirmed', 'Minor'),
(8, 14, 'Injury Timeout', 'Confirmed', 'Moderate'),
(9, 15, 'Timeout', 'Confirmed', 'None'),
(10, 1, 'Substitution', 'Confirmed', 'None'),
(11, 2, 'Timeout', 'Confirmed', 'None'),
(12, 3, 'Yellow Card', 'Confirmed', 'Minor'),
(1, 4, 'Challenge', 'Overturned', 'Minor');

PRINT 'Record data inserted: 25 rows';

-- PLAYERSTATS Table (30 rows)
INSERT INTO PlayerStats (MatchID, PlayerID, Kills, Assists, Aces, Blocks) VALUES
(1, 1, 15, 2, 3, 4),
(1, 2, 3, 25, 1, 2),
(1, 3, 8, 1, 0, 8),
(2, 4, 12, 3, 2, 3),
(2, 5, 18, 1, 4, 5),
(2, 6, 14, 2, 2, 4),
(3, 7, 10, 4, 1, 6),
(3, 8, 2, 28, 3, 1),
(3, 9, 16, 1, 3, 4),
(4, 10, 13, 3, 2, 5),
(4, 11, 17, 2, 4, 3),
(4, 12, 9, 1, 1, 7),
(5, 13, 11, 5, 2, 4),
(5, 14, 15, 2, 3, 6),
(5, 15, 3, 26, 1, 2),
(6, 16, 14, 3, 2, 5),
(6, 17, 12, 2, 3, 4),
(6, 18, 8, 2, 0, 6),
(7, 19, 16, 1, 4, 3),
(7, 20, 2, 24, 2, 1),
(8, 21, 13, 3, 3, 5),
(8, 22, 10, 4, 1, 7),
(9, 23, 18, 2, 5, 4),
(9, 24, 4, 27, 2, 2),
(10, 25, 11, 3, 2, 6),
(10, 26, 15, 2, 3, 4),
(11, 27, 9, 1, 1, 8),
(12, 28, 3, 29, 2, 1),
(13, 29, 17, 2, 4, 5),
(14, 30, 12, 4, 2, 6);

PRINT 'PlayerStats data inserted: 30 rows';

-- STRATEGYPLAN Table (15 rows)
INSERT INTO StrategyPlan (TeamID, MatchID, OpponentTeamID, KeyFactors, TargetedWeaknesses, OurStrengths) VALUES
(1, 1, 2, 'Focus on strong serving game', 'Weak middle blocking', 'Excellent outside hitters'),
(3, 2, 4, 'Quick tempo offense', 'Inconsistent passing', 'Height advantage at net'),
(5, 3, 6, 'Defensive positioning', 'Weak serve receive', 'Strong defensive specialists'),
(7, 4, 8, 'Aggressive blocking', 'Limited setter options', 'Experienced blockers'),
(9, 5, 10, 'Mix up offensive plays', 'Predictable rotations', 'Versatile attackers'),
(11, 6, 12, 'Target weak side hitters', 'Right side defense', 'Left-handed advantage'),
(13, 7, 14, 'Pressure serving', 'Weak libero', 'Powerful servers'),
(15, 8, 16, 'Fast-paced offense', 'Slow transition', 'Athletic middles'),
(17, 9, 18, 'Exploit gaps in defense', 'Poor communication', 'Smart setters'),
(19, 10, 20, 'Consistent serving', 'Weak backcourt', 'Strong serve receive'),
(1, 11, 3, 'Utilize height advantage', 'Shorter blockers', 'Tall front row'),
(2, 12, 4, 'Quick sets to middle', 'Slow middle blockers', 'Fast offense'),
(5, 13, 7, 'Strategic timeouts', 'Mental fatigue late', 'Deep bench'),
(6, 14, 8, 'Aggressive serving zones', 'Weak back left', 'Accurate servers'),
(9, 15, 11, 'Vary attack angles', 'Limited blocking range', 'Creative setters');

PRINT 'StrategyPlan data inserted: 15 rows';

-- MATCHTEAMASSIGN Table (30 rows)
INSERT INTO MatchTeamAssign (MatchID, PlayerID, HomeTeamID, AwayTeamID, StartTime, EndTime, Role, PlayerPosition) VALUES
-- Match 1: Team 1 vs Team 2
(1, 1, 1, 2, '2025-03-05 18:00:00', '2025-03-05 19:45:00', 'Starter', 'Outside Hitter'),
(1, 2, 1, 2, '2025-03-05 18:00:00', '2025-03-05 19:45:00', 'Starter', 'Setter'),
-- Match 2: Team 3 vs Team 4
(2, 3, 3, 4, '2025-03-06 19:00:00', '2025-03-06 21:10:00', 'Starter', 'Middle Blocker'),
(2, 4, 3, 4, '2025-03-06 19:00:00', '2025-03-06 21:10:00', 'Starter', 'Libero'),
-- Match 3: Team 5 vs Team 6
(3, 5, 5, 6, '2025-06-20 17:30:00', '2025-06-20 19:05:00', 'Starter', 'Opposite Hitter'),
(3, 6, 5, 6, '2025-06-20 17:30:00', '2025-06-20 19:05:00', 'Starter', 'Outside Hitter'),
-- Match 4: Team 7 vs Team 8
(4, 7, 7, 8, '2025-06-22 18:30:00', '2025-06-22 20:25:00', 'Starter', 'Middle Blocker'),
(4, 8, 7, 8, '2025-06-22 18:30:00', '2025-06-22 20:25:00', 'Starter', 'Setter'),
-- Match 5: Team 9 vs Team 10
(5, 9, 9, 10, '2025-09-15 19:00:00', '2025-09-15 21:05:00', 'Starter', 'Libero'),
(5, 10, 9, 10, '2025-09-15 19:00:00', '2025-09-15 21:05:00', 'Starter', 'Opposite Hitter'),
-- Match 6: Team 11 vs Team 12
(6, 11, 11, 12, '2025-09-17 17:00:00', '2025-09-17 18:40:00', 'Starter', 'Outside Hitter'),
(6, 12, 11, 12, '2025-09-17 17:00:00', '2025-09-17 18:40:00', 'Starter', 'Middle Blocker'),
-- Match 7: Team 13 vs Team 14
(7, 13, 13, 14, '2025-12-05 18:00:00', '2025-12-05 19:50:00', 'Starter', 'Setter'),
(7, 14, 13, 14, '2025-12-05 18:00:00', '2025-12-05 19:50:00', 'Starter', 'Libero'),
-- Match 8: Team 15 vs Team 16
(8, 15, 15, 16, '2025-12-07 19:30:00', '2025-12-07 21:45:00', 'Starter', 'Outside Hitter'),
(8, 16, 15, 16, '2025-12-07 19:30:00', '2025-12-07 21:45:00', 'Starter', 'Opposite Hitter'),
-- Match 9: Team 17 vs Team 18
(9, 17, 17, 18, '2025-04-10 18:00:00', '2025-04-10 19:38:00', 'Starter', 'Middle Blocker'),
(9, 18, 17, 18, '2025-04-10 18:00:00', '2025-04-10 19:38:00', 'Starter', 'Setter'),
-- Match 10: Team 19 vs Team 20
(10, 19, 19, 20, '2025-04-12 17:30:00', '2025-04-12 19:22:00', 'Starter', 'Outside Hitter'),
(10, 20, 19, 20, '2025-04-12 17:30:00', '2025-04-12 19:22:00', 'Starter', 'Libero'),
-- Match 11: Team 1 vs Team 3
(11, 21, 1, 3, '2025-04-15 19:00:00', '2025-04-15 20:48:00', 'Starter', 'Opposite Hitter'),
(11, 22, 1, 3, '2025-04-15 19:00:00', '2025-04-15 20:48:00', 'Starter', 'Middle Blocker'),
-- Match 12: Team 2 vs Team 4
(12, 23, 2, 4, '2025-04-17 18:30:00', '2025-04-17 20:30:00', 'Starter', 'Setter'),
(12, 24, 2, 4, '2025-04-17 18:30:00', '2025-04-17 20:30:00', 'Starter', 'Outside Hitter'),
-- Match 13: Team 5 vs Team 7
(13, 25, 5, 7, '2025-08-05 17:00:00', '2025-08-05 18:42:00', 'Starter', 'Libero'),
(13, 26, 5, 7, '2025-08-05 17:00:00', '2025-08-05 18:42:00', 'Starter', 'Opposite Hitter'),
-- Match 14: Team 6 vs Team 8
(14, 27, 6, 8, '2025-08-08 19:00:00', '2025-08-08 20:58:00', 'Starter', 'Middle Blocker'),
(14, 28, 6, 8, '2025-08-08 19:00:00', '2025-08-08 20:58:00', 'Starter', 'Setter'),
-- Match 15: Team 9 vs Team 11
(15, 29, 9, 11, '2025-05-15 18:00:00', '2025-05-15 19:36:00', 'Starter', 'Outside Hitter'),
(15, 30, 9, 11, '2025-05-15 18:00:00', '2025-05-15 19:36:00', 'Starter', 'Libero');

PRINT 'MatchTeamAssign data inserted: 30 rows';
PRINT 'Part 4 completed successfully!';
GO

-- =============================================
-- Part 5: Player/Coach Assignments and Orders
-- =============================================

-- PLAYERASSIGN Table (30 rows)
INSERT INTO PlayerAssign (PlayerID, TeamID, SeasonID, HireDate, TerminateDate, Position) VALUES
(1, 1, 1, '2025-03-01', NULL, 'Outside Hitter'),
(2, 1, 1, '2025-03-01', NULL, 'Setter'),
(3, 2, 1, '2025-03-01', NULL, 'Middle Blocker'),
(4, 2, 1, '2025-03-01', NULL, 'Libero'),
(5, 3, 1, '2025-03-01', NULL, 'Opposite Hitter'),
(6, 3, 1, '2025-03-01', NULL, 'Outside Hitter'),
(7, 4, 1, '2025-03-01', NULL, 'Middle Blocker'),
(8, 4, 1, '2025-03-01', NULL, 'Setter'),
(9, 5, 2, '2025-06-01', NULL, 'Libero'),
(10, 5, 2, '2025-06-01', NULL, 'Opposite Hitter'),
(11, 6, 2, '2025-06-01', NULL, 'Outside Hitter'),
(12, 6, 2, '2025-06-01', NULL, 'Middle Blocker'),
(13, 7, 2, '2025-06-01', NULL, 'Setter'),
(14, 7, 2, '2025-06-01', NULL, 'Libero'),
(15, 8, 3, '2024-09-01', NULL, 'Outside Hitter'),
(16, 8, 3, '2024-09-01', NULL, 'Opposite Hitter'),
(17, 9, 3, '2024-09-01', NULL, 'Middle Blocker'),
(18, 9, 3, '2024-09-01', NULL, 'Setter'),
(19, 10, 3, '2024-09-01', NULL, 'Outside Hitter'),
(20, 10, 3, '2024-09-01', NULL, 'Libero'),
(21, 11, 4, '2024-12-01', NULL, 'Opposite Hitter'),
(22, 11, 4, '2024-12-01', NULL, 'Middle Blocker'),
(23, 12, 4, '2024-12-01', NULL, 'Setter'),
(24, 12, 4, '2024-12-01', NULL, 'Outside Hitter'),
(25, 13, 4, '2024-12-01', NULL, 'Libero'),
(26, 14, 5, '2024-03-01', '2024-05-31', 'Opposite Hitter'),
(27, 15, 5, '2024-03-01', NULL, 'Middle Blocker'),
(28, 16, 5, '2024-03-01', NULL, 'Setter'),
(29, 17, 6, '2024-06-01', NULL, 'Outside Hitter'),
(30, 18, 6, '2024-06-01', NULL, 'Libero');

PRINT 'PlayerAssign data inserted: 30 rows';

-- COACHASSIGN Table (20 rows)
INSERT INTO CoachAssign (CoachID, TeamID, SeasonID, HireDate, TerminateDate, CoachRole, ContractType) VALUES
(1, 1, 1, '2025-03-01', NULL, 'Head Coach', 'Full-time'),
(2, 2, 1, '2025-03-01', NULL, 'Head Coach', 'Full-time'),
(3, 3, 1, '2025-03-01', NULL, 'Head Coach', 'Full-time'),
(4, 4, 1, '2025-03-01', NULL, 'Head Coach', 'Full-time'),
(5, 5, 2, '2025-06-01', NULL, 'Head Coach', 'Full-time'),
(6, 6, 2, '2025-06-01', NULL, 'Head Coach', 'Seasonal'),
(7, 7, 2, '2025-06-01', NULL, 'Head Coach', 'Full-time'),
(8, 8, 3, '2024-09-01', NULL, 'Head Coach', 'Full-time'),
(9, 9, 3, '2024-09-01', NULL, 'Assistant Coach', 'Part-time'),
(10, 10, 3, '2024-09-01', NULL, 'Head Coach', 'Seasonal'),
(11, 11, 4, '2024-12-01', NULL, 'Head Coach', 'Full-time'),
(12, 12, 4, '2024-12-01', NULL, 'Assistant Coach', 'Part-time'),
(13, 13, 4, '2024-12-01', NULL, 'Head Coach', 'Full-time'),
(14, 14, 5, '2024-03-01', '2024-05-31', 'Head Coach', 'Seasonal'),
(15, 15, 5, '2024-03-01', NULL, 'Head Coach', 'Full-time'),
(1, 16, 5, '2024-03-01', NULL, 'Assistant Coach', 'Part-time'),
(2, 17, 6, '2024-06-01', NULL, 'Head Coach', 'Full-time'),
(3, 18, 6, '2024-06-01', NULL, 'Head Coach', 'Seasonal'),
(4, 19, 1, '2025-03-01', NULL, 'Assistant Coach', 'Part-time'),
(5, 20, 1, '2025-03-01', NULL, 'Head Coach', 'Full-time');

PRINT 'CoachAssign data inserted: 20 rows';

-- ORDER Table (20 rows)
INSERT INTO [Order] (CustomerID, OrderDate, OrderStatus, GrandTotal, Tax) VALUES
(1, '2025-02-15', 'Completed', 175.00, 15.00),
(2, '2025-02-16', 'Completed', 230.00, 20.00),
(3, '2025-02-17', 'Pending', 145.00, 12.50),
(4, '2025-02-18', 'Completed', 290.00, 25.00),
(5, '2025-02-19', 'Completed', 160.00, 14.00),
(6, '2025-02-20', 'Processing', 200.00, 17.50),
(7, '2025-02-21', 'Completed', 310.00, 27.00),
(8, '2025-02-22', 'Completed', 125.00, 11.00),
(9, '2025-02-23', 'Pending', 275.00, 24.00),
(10, '2025-02-24', 'Completed', 185.00, 16.00),
(11, '2025-02-25', 'Completed', 220.00, 19.00),
(12, '2025-02-26', 'Processing', 155.00, 13.50),
(13, '2025-02-27', 'Completed', 340.00, 29.50),
(14, '2025-02-28', 'Completed', 190.00, 16.50),
(15, '2025-03-01', 'Pending', 265.00, 23.00),
(1, '2025-03-02', 'Completed', 180.00, 15.50),
(2, '2025-03-03', 'Completed', 210.00, 18.00),
(3, '2025-03-04', 'Processing', 150.00, 13.00),
(4, '2025-03-05', 'Completed', 295.00, 25.50),
(5, '2025-03-06', 'Completed', 170.00, 14.75);

PRINT 'Order data inserted: 20 rows';

-- PAYMENT Table (20 rows)
INSERT INTO Payment (OrderID, Method, Amount, PaidAt, Status) VALUES
(1, 'Credit Card', 175.00, '2025-02-15', 'Completed'),
(2, 'Debit Card', 230.00, '2025-02-16', 'Completed'),
(3, 'PayPal', 145.00, '2025-02-17', 'Pending'),
(4, 'Credit Card', 290.00, '2025-02-18', 'Completed'),
(5, 'Cash', 160.00, '2025-02-19', 'Completed'),
(6, 'Credit Card', 200.00, '2025-02-20', 'Processing'),
(7, 'Debit Card', 310.00, '2025-02-21', 'Completed'),
(8, 'PayPal', 125.00, '2025-02-22', 'Completed'),
(9, 'Credit Card', 275.00, '2025-02-23', 'Pending'),
(10, 'Cash', 185.00, '2025-02-24', 'Completed'),
(11, 'Credit Card', 220.00, '2025-02-25', 'Completed'),
(12, 'Debit Card', 155.00, '2025-02-26', 'Processing'),
(13, 'Credit Card', 340.00, '2025-02-27', 'Completed'),
(14, 'PayPal', 190.00, '2025-02-28', 'Completed'),
(15, 'Credit Card', 265.00, '2025-03-01', 'Pending'),
(16, 'Cash', 180.00, '2025-03-02', 'Completed'),
(17, 'Credit Card', 210.00, '2025-03-03', 'Completed'),
(18, 'Debit Card', 150.00, '2025-03-04', 'Processing'),
(19, 'Credit Card', 295.00, '2025-03-05', 'Completed'),
(20, 'PayPal', 170.00, '2025-03-06', 'Completed');

PRINT 'Payment data inserted: 20 rows';

-- REFUND Table (10 rows)
INSERT INTO Refund (PaymentID, Amount, Reason, RefundedDate) VALUES
(2, 230.00, 'Event cancelled', '2025-02-20'),
(4, 145.00, 'Customer request - duplicate purchase', '2025-02-22'),
(7, 155.00, 'Seat change request', '2025-02-25'),
(10, 75.00, 'Partial refund - seat issue', '2025-02-27'),
(1, 175.00, 'Event rescheduled', '2025-02-28'),
(13, 340.00, 'Order cancelled by customer', '2025-03-01'),
(5, 160.00, 'Venue change', '2025-03-02'),
(8, 125.00, 'Customer no longer available', '2025-03-03'),
(16, 90.00, 'Partial refund - late notification', '2025-03-05'),
(14, 190.00, 'System error in booking', '2025-03-06');

PRINT 'Refund data inserted: 10 rows';

-- TICKET Table (30 rows)
INSERT INTO Ticket (OrderID, MatchID, SeatID, Barcode, Status, UsedAt, TicketType, DeliveryMethod) VALUES
(1, 1, 1, 'BAR001M001S001', 'Valid', NULL, 'VIP', 'Email'),
(1, 1, 2, 'BAR002M001S002', 'Valid', NULL, 'VIP', 'Email'),
(2, 2, 6, 'BAR003M002S006', 'Used', '2025-03-06', 'VIP', 'Mobile'),
(4, 3, 11, 'BAR004M003S011', 'Valid', NULL, 'VIP', 'Email'),
(5, 4, 16, 'BAR005M004S016', 'Valid', NULL, 'VIP', 'Print'),
(6, 5, 21, 'BAR006M005S021', 'Valid', NULL, 'VIP', 'Email'),
(7, 6, 26, 'BAR007M006S026', 'Valid', NULL, 'VIP', 'Mobile'),
(8, 7, 31, 'BAR008M007S031', 'Valid', NULL, 'VIP', 'Email'),
(10, 8, 3, 'BAR009M008S003', 'Valid', NULL, 'Courtside', 'Mobile'),
(11, 9, 8, 'BAR010M009S008', 'Valid', NULL, 'Courtside', 'Email'),
(13, 10, 13, 'BAR011M010S013', 'Valid', NULL, 'Courtside', 'Print'),
(14, 11, 18, 'BAR012M011S018', 'Valid', NULL, 'Courtside', 'Email'),
(16, 12, 23, 'BAR013M012S023', 'Valid', NULL, 'Courtside', 'Mobile'),
(17, 13, 28, 'BAR014M013S028', 'Valid', NULL, 'Courtside', 'Email'),
(19, 14, 33, 'BAR015M014S033', 'Valid', NULL, 'Courtside', 'Print'),
(20, 15, 38, 'BAR016M015S038', 'Valid', NULL, 'Courtside', 'Mobile'),
(3, 1, 4, 'BAR017M001S004', 'Valid', NULL, 'Standard', 'Email'),
(3, 1, 5, 'BAR018M001S005', 'Valid', NULL, 'Standard', 'Email'),
(6, 2, 7, 'BAR019M002S007', 'Valid', NULL, 'Standard', 'Mobile'),
(9, 3, 9, 'BAR020M003S009', 'Valid', NULL, 'Standard', 'Email'),
(9, 3, 10, 'BAR021M003S010', 'Cancelled', NULL, 'Standard', 'Email'),
(11, 4, 12, 'BAR022M004S012', 'Valid', NULL, 'Standard', 'Print'),
(12, 5, 14, 'BAR023M005S014', 'Valid', NULL, 'Standard', 'Email'),
(12, 5, 15, 'BAR024M005S015', 'Valid', NULL, 'Standard', 'Email'),
(15, 6, 17, 'BAR025M006S017', 'Valid', NULL, 'Standard', 'Mobile'),
(15, 6, 19, 'BAR026M006S019', 'Valid', NULL, 'Standard', 'Mobile'),
(18, 7, 20, 'BAR027M007S020', 'Valid', NULL, 'Standard', 'Email'),
(18, 8, 22, 'BAR028M008S022', 'Valid', NULL, 'Standard', 'Print'),
(19, 9, 24, 'BAR029M009S024', 'Valid', NULL, 'Standard', 'Email'),
(20, 10, 25, 'BAR030M010S025', 'Valid', NULL, 'Standard', 'Mobile');

PRINT 'Ticket data inserted: 30 rows';
PRINT 'Part 5 completed successfully!';
GO

-- =============================================
-- Final Verification
-- =============================================

PRINT '';
PRINT '======================================';
PRINT 'ALL DATA INSERTION COMPLETED!';
PRINT '======================================';
PRINT '';

-- Final verification query
SELECT TableName, RecordCount FROM (
    SELECT 'CoachAssign' AS TableName, COUNT(*) AS RecordCount FROM CoachAssign
    UNION ALL
    SELECT 'Coach', COUNT(*) FROM Coach
    UNION ALL
    SELECT 'CourtSide_Seat', COUNT(*) FROM CourtSide_Seat
    UNION ALL
    SELECT 'Customer', COUNT(*) FROM Customer
    UNION ALL
    SELECT 'Indoor_Venue', COUNT(*) FROM Indoor_Venue
    UNION ALL
    SELECT 'Match', COUNT(*) FROM Match
    UNION ALL
    SELECT 'MatchTeamAssign', COUNT(*) FROM MatchTeamAssign
    UNION ALL
    SELECT 'Order', COUNT(*) FROM [Order]
    UNION ALL
    SELECT 'Outdoor_Venue', COUNT(*) FROM Outdoor_Venue
    UNION ALL
    SELECT 'Payment', COUNT(*) FROM Payment
    UNION ALL
    SELECT 'Player', COUNT(*) FROM Player
    UNION ALL
    SELECT 'PlayerAssign', COUNT(*) FROM PlayerAssign
    UNION ALL
    SELECT 'PlayerStats', COUNT(*) FROM PlayerStats
    UNION ALL
    SELECT 'Player_Historic_Stats', COUNT(*) FROM Player_Historic_Stats
    UNION ALL
    SELECT 'Queue', COUNT(*) FROM Queue
    UNION ALL
    SELECT 'Record', COUNT(*) FROM Record
    UNION ALL
    SELECT 'Referee', COUNT(*) FROM Referee
    UNION ALL
    SELECT 'Refund', COUNT(*) FROM Refund
    UNION ALL
    SELECT 'Seat', COUNT(*) FROM Seat
    UNION ALL
    SELECT 'Season', COUNT(*) FROM Season
    UNION ALL
    SELECT 'Section', COUNT(*) FROM Section
    UNION ALL
    SELECT 'StrategyPlan', COUNT(*) FROM StrategyPlan
    UNION ALL
    SELECT 'Team', COUNT(*) FROM Team
    UNION ALL
    SELECT 'Team_Historic_Stats', COUNT(*) FROM Team_Historic_Stats
    UNION ALL
    SELECT 'Ticket', COUNT(*) FROM Ticket
    UNION ALL
    SELECT 'Tournament', COUNT(*) FROM Tournament
    UNION ALL
    SELECT 'VIP_Seat', COUNT(*) FROM VIP_Seat
    UNION ALL
    SELECT 'Venue', COUNT(*) FROM Venue
) AS RowCounts
ORDER BY TableName;

PRINT '';
PRINT 'Data insertion script completed successfully!';



USE VolleyballLeague;
GO

-- =============================================
-- 6.1 Extra Customers (IDs 16+ auto-created)
-- =============================================
DECLARE @i INT = 16;

WHILE @i <= 100
BEGIN
    INSERT INTO Customer (FirstName, LastName, Email, Phone, Street, City, StateProvince, Country, ZipCode)
    VALUES (
        'AutoFirst' + CAST(@i AS VARCHAR(5)),
        'AutoLast'  + CAST(@i AS VARCHAR(5)),
        'auto' + CAST(@i AS VARCHAR(5)) + '@demo.com',
        '555-' + RIGHT('0000' + CAST(@i AS VARCHAR(4)), 4),
        CAST(@i AS VARCHAR(5)) + ' Generated St',
        CASE 
            WHEN @i % 5 = 0 THEN 'Boston'
            WHEN @i % 5 = 1 THEN 'Cambridge'
            WHEN @i % 5 = 2 THEN 'Somerville'
            WHEN @i % 5 = 3 THEN 'Quincy'
            ELSE 'Newton'
        END,
        'MA',
        'USA',
        '02' + RIGHT('1000' + CAST(@i AS VARCHAR(4)), 4)
    );

    SET @i += 1;
END;

PRINT 'Extra Customer data inserted (IDs 16+).';
GO

-- =============================================
-- 6.2 Extra Orders (200 more orders over time)
-- =============================================
DECLARE @orderCounter INT = 1;
DECLARE @custId INT;
DECLARE @orderDate DATE;
DECLARE @grandTotal DECIMAL(10,2);
DECLARE @tax DECIMAL(10,2);
DECLARE @status VARCHAR(20);

WHILE @orderCounter <= 200
BEGIN
    -- Cycle customers between 1 and 100
    SET @custId = ((@orderCounter - 1) % 100) + 1;

    -- Orders from 2025-01-01 onward
    SET @orderDate = DATEADD(DAY, @orderCounter - 1, '2025-01-01');

    -- Some price variation
    SET @grandTotal = 80.00 + (@orderCounter % 15) * 12.50;
    SET @tax        = CAST(@grandTotal * 0.085 AS DECIMAL(10,2));

    -- Mix of statuses
    SET @status =
        CASE 
            WHEN @orderCounter % 7 = 0 THEN 'Pending'
            WHEN @orderCounter % 5 = 0 THEN 'Processing'
            ELSE 'Completed'
        END;

    INSERT INTO [Order] (CustomerID, OrderDate, OrderStatus, GrandTotal, Tax)
    VALUES (@custId, @orderDate, @status, @grandTotal, @tax);

    SET @orderCounter += 1;
END;

PRINT 'Extra Order data inserted: 200 rows.';
GO

-- =============================================
-- 6.3 Extra Payments (for all new non-pending orders)
-- creates payment rows for orders that have no payment yet
-- =============================================
INSERT INTO Payment (OrderID, Method, Amount, PaidAt, Status)
SELECT 
    o.OrderID,
    CASE 
        WHEN o.OrderID % 3 = 0 THEN 'Credit Card'
        WHEN o.OrderID % 3 = 1 THEN 'Debit Card'
        ELSE 'PayPal'
    END AS Method,
    o.GrandTotal,
    o.OrderDate,
    CASE 
        WHEN o.OrderStatus = 'Completed' THEN 'Completed'
        ELSE 'Processing'
    END AS Status
FROM [Order] o
LEFT JOIN Payment p ON p.OrderID = o.OrderID
WHERE p.OrderID IS NULL         -- only orders without payment
  AND o.OrderStatus <> 'Pending';

PRINT 'Extra Payment data inserted for new Orders.';
GO

-- =============================================
-- 6.4 Extra Tickets (400 more tickets)
--  - Cycles through Orders, Matches (1–15), Seats (1–50)
--  - Creates a nice spread of ticket types & delivery methods
-- =============================================
DECLARE @ticketCounter INT = 1;
DECLARE @orderId INT;
DECLARE @matchId INT;
DECLARE @seatId INT;
DECLARE @barcode VARCHAR(50);
DECLARE @ticketType VARCHAR(20);
DECLARE @deliveryMethod VARCHAR(20);
DECLARE @usedAt DATE;

-- Figure out max OrderID to know the range
DECLARE @maxOrderId INT;
SELECT @maxOrderId = MAX(OrderID) FROM [Order];

WHILE @ticketCounter <= 400
BEGIN
    SET @orderId = ((@ticketCounter - 1) % @maxOrderId) + 1;
    SET @matchId = ((@ticketCounter - 1) % 15) + 1;   -- Matches 1–15
    SET @seatId  = ((@ticketCounter - 1) % 50) + 1;   -- Seats 1–50

    -- Simple barcode pattern
    SET @barcode = 'AUTO_BAR_' 
                   + RIGHT('0000' + CAST(@ticketCounter AS VARCHAR(10)), 4)
                   + '_M' + RIGHT('00' + CAST(@matchId AS VARCHAR(10)), 2)
                   + '_S' + RIGHT('00' + CAST(@seatId AS VARCHAR(10)), 2);

    SET @ticketType =
        CASE 
            WHEN @ticketCounter % 10 = 0 THEN 'VIP'
            WHEN @ticketCounter % 3  = 0 THEN 'Courtside'
            ELSE 'Standard'
        END;

    SET @deliveryMethod =
        CASE 
            WHEN @ticketCounter % 4 = 0 THEN 'Print'
            WHEN @ticketCounter % 4 = 1 THEN 'Email'
            ELSE 'Mobile'
        END;

    -- Random-ish usage: some used, some not
    SET @usedAt = CASE 
                      WHEN @ticketCounter % 5 = 0 THEN DATEADD(DAY, (@ticketCounter % 20), '2025-03-01')
                      ELSE NULL
                  END;

    INSERT INTO Ticket (OrderID, MatchID, SeatID, Barcode, Status, UsedAt, TicketType, DeliveryMethod)
    VALUES (
        @orderId,
        @matchId,
        @seatId,
        @barcode,
        CASE WHEN @usedAt IS NULL THEN 'Valid' ELSE 'Used' END,
        @usedAt,
        @ticketType,
        @deliveryMethod
    );

    SET @ticketCounter += 1;
END;

PRINT 'Extra Ticket data inserted: 400 rows.';
GO

-- =============================================
-- 6.5 Quick row count check for Power BI
-- =============================================
SELECT 'Customer' AS TableName, COUNT(*) AS [RowCount] FROM Customer
UNION ALL
SELECT 'Order', COUNT(*) FROM [Order]
UNION ALL
SELECT 'Payment', COUNT(*) FROM Payment
UNION ALL
SELECT 'Ticket', COUNT(*) FROM Ticket;
GO
