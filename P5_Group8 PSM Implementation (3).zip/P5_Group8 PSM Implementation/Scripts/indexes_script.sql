-- =============================================
-- Volleyball League Database - Indexes Script
-- Contains: Non-Clustered Indexes for Performance Optimization
-- =============================================

USE VolleyballLeague;
GO

PRINT '========================================';
PRINT 'Creating Non-Clustered Indexes';
PRINT '========================================';
PRINT '';

-- =============================================
-- Index 1: Customer Email Search
-- Purpose: Optimize customer lookups by email (login scenarios)
-- Usage: Frequently used for customer authentication and lookup
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Customer_Email_Optimized' AND object_id = OBJECT_ID('Customer'))
    DROP INDEX IX_Customer_Email_Optimized ON Customer;
GO

CREATE NONCLUSTERED INDEX IX_Customer_Email_Optimized
ON Customer(Email)
INCLUDE (CustomerID, FirstName, LastName, Phone);
GO

PRINT 'Index 1 created: IX_Customer_Email_Optimized on Customer(Email)';
PRINT 'Purpose: Fast customer lookup by email with included columns for common queries';
PRINT '';

-- =============================================
-- Index 2: Match Lookup by Teams
-- Purpose: Optimize queries that search for matches by team combinations
-- Usage: Used for team history, head-to-head statistics
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Match_TeamCombination' AND object_id = OBJECT_ID('Match'))
    DROP INDEX IX_Match_TeamCombination ON Match;
GO

CREATE NONCLUSTERED INDEX IX_Match_TeamCombination
ON Match(HomeTeam_ID, AwayTeam_ID)
INCLUDE (MatchID, WinningTeam_ID, Score, MatchDuration);
GO

PRINT 'Index 2 created: IX_Match_TeamCombination on Match(HomeTeam_ID, AwayTeam_ID)';
PRINT 'Purpose: Efficient team matchup queries and head-to-head statistics';
PRINT '';

-- =============================================
-- Index 3: Ticket Search by Match
-- Purpose: Optimize ticket queries by match for attendance and sales reports
-- Usage: Used for match attendance reports, ticket availability checks
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Ticket_Match_Status' AND object_id = OBJECT_ID('Ticket'))
    DROP INDEX IX_Ticket_Match_Status ON Ticket;
GO

CREATE NONCLUSTERED INDEX IX_Ticket_Match_Status
ON Ticket(MatchID, Status)
INCLUDE (TicketID, OrderID, SeatID, TicketType, Barcode);
GO

PRINT 'Index 3 created: IX_Ticket_Match_Status on Ticket(MatchID, Status)';
PRINT 'Purpose: Fast ticket lookups by match and status for sales reporting';
PRINT '';

-- =============================================
-- Index 4: Player Statistics by Player
-- Purpose: Optimize player performance queries
-- Usage: Used for player statistics, performance analysis, leaderboards
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_PlayerStats_PlayerID' AND object_id = OBJECT_ID('PlayerStats'))
    DROP INDEX IX_PlayerStats_PlayerID ON PlayerStats;
GO

CREATE NONCLUSTERED INDEX IX_PlayerStats_PlayerID
ON PlayerStats(PlayerID)
INCLUDE (MatchID, Kills, Assists, Aces, Blocks);
GO

PRINT 'Index 4 created: IX_PlayerStats_PlayerID on PlayerStats(PlayerID)';
PRINT 'Purpose: Efficient player statistics aggregation and performance queries';
PRINT '';

-- =============================================
-- Index 5: Order Status and Date
-- Purpose: Optimize order queries filtered by status and date range
-- Usage: Used for order management, financial reports, pending order processing
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Order_Status_Date' AND object_id = OBJECT_ID('[Order]'))
    DROP INDEX IX_Order_Status_Date ON [Order];
GO

CREATE NONCLUSTERED INDEX IX_Order_Status_Date
ON [Order](OrderStatus, OrderDate DESC)
INCLUDE (OrderID, CustomerID, GrandTotal, Tax);
GO

PRINT 'Index 5 created: IX_Order_Status_Date on [Order](OrderStatus, OrderDate)';
PRINT 'Purpose: Fast order filtering by status and date for reports and processing';
PRINT '';

-- =============================================
-- Index 6: Seat Availability by Section
-- Purpose: Optimize seat availability queries for ticket sales
-- Usage: Used for seat selection interface, availability checks
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Seat_Section_Status' AND object_id = OBJECT_ID('Seat'))
    DROP INDEX IX_Seat_Section_Status ON Seat;
GO

CREATE NONCLUSTERED INDEX IX_Seat_Section_Status
ON Seat(SectionID, Status)
INCLUDE (SeatID, SeatNumber, RowNumber, BasePrice, IsAccessible);
GO

PRINT 'Index 6 created: IX_Seat_Section_Status on Seat(SectionID, Status)';
PRINT 'Purpose: Efficient seat availability checks by section for ticket purchase';
PRINT '';

-- =============================================
-- Index 7: Queue Scheduling
-- Purpose: Optimize queue queries for match scheduling
-- Usage: Used for scheduling system, venue availability checks
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Queue_Venue_Tournament_Status' AND object_id = OBJECT_ID('Queue'))
    DROP INDEX IX_Queue_Venue_Tournament_Status ON Queue;
GO

CREATE NONCLUSTERED INDEX IX_Queue_Venue_Tournament_Status
ON Queue(VenueID, TournamentID, Status)
INCLUDE (QueueID, HomeTeam_ID, AwayTeam_ID, ScheduledTime, SchedulingPriority);
GO

PRINT 'Index 7 created: IX_Queue_Venue_Tournament_Status on Queue';
PRINT 'Purpose: Efficient match scheduling and venue availability queries';
PRINT '';

-- =============================================
-- Index 8: Player Assignment by Season
-- Purpose: Optimize queries for player rosters by season
-- Usage: Used for roster management, team composition reports
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_PlayerAssign_Season_Team' AND object_id = OBJECT_ID('PlayerAssign'))
    DROP INDEX IX_PlayerAssign_Season_Team ON PlayerAssign;
GO

CREATE NONCLUSTERED INDEX IX_PlayerAssign_Season_Team
ON PlayerAssign(SeasonID, TeamID)
INCLUDE (PlayerID, Position, HireDate, TerminateDate);
GO

PRINT 'Index 8 created: IX_PlayerAssign_Season_Team on PlayerAssign';
PRINT 'Purpose: Fast team roster queries by season for reports';
PRINT '';

-- =============================================
-- Index 9: Coach Assignment by Season
-- Purpose: Optimize queries for coach assignments by season
-- Usage: Used for coaching staff reports, contract management
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_CoachAssign_Season_Team' AND object_id = OBJECT_ID('CoachAssign'))
    DROP INDEX IX_CoachAssign_Season_Team ON CoachAssign;
GO

CREATE NONCLUSTERED INDEX IX_CoachAssign_Season_Team
ON CoachAssign(SeasonID, TeamID)
INCLUDE (CoachID, CoachRole, HireDate, TerminateDate, ContractType);
GO

PRINT 'Index 9 created: IX_CoachAssign_Season_Team on CoachAssign';
PRINT 'Purpose: Efficient coaching staff queries and contract management';
PRINT '';

-- =============================================
-- Index 10: Payment Status and Date
-- Purpose: Optimize payment queries for financial reporting
-- Usage: Used for payment processing, reconciliation, financial reports
-- =============================================
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Payment_Status_Date' AND object_id = OBJECT_ID('Payment'))
    DROP INDEX IX_Payment_Status_Date ON Payment;
GO

CREATE NONCLUSTERED INDEX IX_Payment_Status_Date
ON Payment(Status, PaidAt DESC)
INCLUDE (PaymentID, OrderID, Method, Amount);
GO

PRINT 'Index 10 created: IX_Payment_Status_Date on Payment(Status, PaidAt)';
PRINT 'Purpose: Fast payment filtering for financial reports and reconciliation';
PRINT '';

-- =============================================
-- Index Analysis and Performance Statistics
-- =============================================

PRINT '========================================';
PRINT 'Index Statistics Summary';
PRINT '========================================';
PRINT '';

-- Display all non-clustered indexes created
SELECT 
    OBJECT_NAME(i.object_id) AS TableName,
    i.name AS IndexName,
    i.type_desc AS IndexType,
    STUFF((
        SELECT ', ' + c.name
        FROM sys.index_columns ic
        INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
        WHERE ic.object_id = i.object_id 
        AND ic.index_id = i.index_id
        AND ic.is_included_column = 0
        ORDER BY ic.key_ordinal
        FOR XML PATH('')
    ), 1, 2, '') AS KeyColumns,
    STUFF((
        SELECT ', ' + c.name
        FROM sys.index_columns ic
        INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
        WHERE ic.object_id = i.object_id 
        AND ic.index_id = i.index_id
        AND ic.is_included_column = 1
        ORDER BY ic.index_column_id
        FOR XML PATH('')
    ), 1, 2, '') AS IncludedColumns
FROM sys.indexes i
WHERE i.object_id IN (
    OBJECT_ID('Customer'),
    OBJECT_ID('Match'),
    OBJECT_ID('Ticket'),
    OBJECT_ID('PlayerStats'),
    OBJECT_ID('[Order]'),
    OBJECT_ID('Seat'),
    OBJECT_ID('Queue'),
    OBJECT_ID('PlayerAssign'),
    OBJECT_ID('CoachAssign'),
    OBJECT_ID('Payment')
)
AND i.type_desc = 'NONCLUSTERED'
AND i.name LIKE 'IX_%'
ORDER BY TableName, IndexName;

PRINT '';
PRINT '========================================';
PRINT 'Performance Optimization Recommendations';
PRINT '========================================';
PRINT '';
PRINT '1. Monitor index usage using sys.dm_db_index_usage_stats';
PRINT '2. Update statistics regularly: EXEC sp_updatestats';
PRINT '3. Rebuild fragmented indexes periodically';
PRINT '4. Consider filtered indexes for specific query patterns';
PRINT '5. Review execution plans to verify index usage';
PRINT '';

-- =============================================
-- Sample Query Performance Tests
-- =============================================

PRINT '========================================';
PRINT 'Sample Queries to Test Index Performance';
PRINT '========================================';
PRINT '';

-- Test Query 1: Customer lookup by email
PRINT 'Query 1: Customer lookup by email (uses IX_Customer_Email_Optimized)';
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT CustomerID, FirstName, LastName, Email, Phone
FROM Customer
WHERE Email = 'john.smith@email.com';

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
PRINT '';

-- Test Query 2: Match history between two teams
PRINT 'Query 2: Match history between teams (uses IX_Match_TeamCombination)';
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT MatchID, HomeTeam_ID, AwayTeam_ID, WinningTeam_ID, Score
FROM Match
WHERE HomeTeam_ID = 1 AND AwayTeam_ID = 2;

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
PRINT '';

-- Test Query 3: Tickets for a specific match
PRINT 'Query 3: Valid tickets for a match (uses IX_Ticket_Match_Status)';
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT TicketID, OrderID, SeatID, TicketType, Barcode
FROM Ticket
WHERE MatchID = 1 AND Status = 'Valid';

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
PRINT '';

-- Test Query 4: Player statistics
PRINT 'Query 4: Player statistics aggregation (uses IX_PlayerStats_PlayerID)';
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT 
    PlayerID,
    COUNT(*) AS MatchesPlayed,
    SUM(Kills) AS TotalKills,
    SUM(Assists) AS TotalAssists,
    SUM(Aces) AS TotalAces,
    SUM(Blocks) AS TotalBlocks
FROM PlayerStats
WHERE PlayerID = 1
GROUP BY PlayerID;

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
PRINT '';

-- Test Query 5: Available seats in a section
PRINT 'Query 5: Available seats by section (uses IX_Seat_Section_Status)';
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT SeatID, SeatNumber, RowNumber, BasePrice
FROM Seat
WHERE SectionID = 1 AND Status = 'Available';

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
PRINT '';

PRINT '========================================';
PRINT 'Index Script Completed Successfully!';
PRINT 'Total Non-Clustered Indexes Created: 10';
PRINT '========================================';